#!/bin/sh

test -f ${MESON_SOURCE_ROOT}/src/bin/e_fm_shared_types.h

#!/bin/sh
chmod "$1" "${DESTDIR}/$2"

#include "e.h"

/* function protos */
static void        *_create_data(E_Config_Dialog *cfd);
static void         _free_data(E_Config_Dialog *cfd, E_Config_Dialog_Data *cfdata);
static int          _basic_check_changed(E_Config_Dialog *cfd EINA_UNUSED, E_Config_Dialog_Data *cfdata);
static int          _basic_apply_data(E_Config_Dialog *cfd, E_Config_Dialog_Data *cfdata);
static Evas_Object *_basic_create(E_Config_Dialog *cfd, Evas *evas, E_Config_Dialog_Data *cfdata);
static void         _fill_remembers(E_Config_Dialog_Data *cfdata);
static void         _cb_edit(void *data, void *data2 EINA_UNUSED);
static void         _cb_delete(void *data, void *data2);
static void         _cb_list_change(void *data, Evas_Object *obj);

struct _E_Config_Dialog_Data
{
   Evas_Object *list, *btn, *btn2, *name, *class, *title, *role;
   int          remember_dialogs;
   int          remember_fm_wins;
   int          remember_internal_fm_windows_globally;
   Eina_List *cfds;
};

E_Config_Dialog *
e_int_config_remembers(Evas_Object *parent EINA_UNUSED, const char *params EINA_UNUSED)
{
   E_Config_Dialog *cfd;
   E_Config_Dialog_View *v;

   if (e_config_dialog_find("E", "windows/window_remembers")) return NULL;

   v = E_NEW(E_Config_Dialog_View, 1);
   v->create_cfdata = _create_data;
   v->free_cfdata = _free_data;
   v->basic.apply_cfdata = _basic_apply_data;
   v->basic.create_widgets = _basic_create;
   v->basic.check_changed = _basic_check_changed;

   cfd = e_config_dialog_new(NULL, _("Window Remembers"), "E",
                             "windows/window_remembers",
                             "preferences-desktop-window-remember", 0, v, NULL);
   return cfd;
}

/* private functions */
static int
_cb_sort(const void *data1, const void *data2)
{
   const E_Remember *rem1 = NULL;
   const E_Remember *rem2 = NULL;
   const char *d1 = "";
   const char *d2 = "";

   if (!(rem1 = data1)) return 1;
   if (!(rem2 = data2)) return -1;

   if (rem1->name)
     d1 = rem1->name;
   else if (rem1->class)
     d1 = rem1->class;
   else if (rem1->title)
     d1 = rem1->title;
   else if (rem1->role)
     d1 = rem1->role;

   if (rem2->name)
     d2 = rem2->name;
   else if (rem2->class)
     d2 = rem2->class;
   else if (rem2->title)
     d2 = rem2->title;
   else if (rem2->role)
     d2 = rem2->role;

   if (!strcmp(d1, d2))
     return -1;
   else
     return strcmp(d1, d2);
}

static void *
_create_data(E_Config_Dialog *cfd EINA_UNUSED)
{
   E_Config_Dialog_Data *cfdata;

   cfdata = E_NEW(E_Config_Dialog_Data, 1);
   cfdata->remember_dialogs = e_config->remember_internal_windows;
   cfdata->remember_fm_wins = e_config->remember_internal_fm_windows;
   cfdata->remember_internal_fm_windows_globally = e_config->remember_internal_fm_windows_globally;

   return cfdata;
}

static void
_free_data(E_Config_Dialog *cfd, E_Config_Dialog_Data *cfdata)
{
   EINA_LIST_FREE(cfdata->cfds, cfd)
     E_OBJECT_DEL_SET(cfd, NULL);
   free(cfdata);
}

static int
_basic_check_changed(E_Config_Dialog *cfd EINA_UNUSED, E_Config_Dialog_Data *cfdata)
{
   return (cfdata->remember_dialogs != e_config->remember_internal_windows) ||
          (cfdata->remember_fm_wins != e_config->remember_internal_fm_windows) ||
          (cfdata->remember_internal_fm_windows_globally != e_config->remember_internal_fm_windows_globally);
}

static int
_basic_apply_data(E_Config_Dialog *cfd EINA_UNUSED, E_Config_Dialog_Data *cfdata)
{
   e_config->remember_internal_windows = cfdata->remember_dialogs;
   e_config->remember_internal_fm_windows = cfdata->remember_fm_wins;
   e_config->remember_internal_fm_windows_globally = cfdata->remember_internal_fm_windows_globally;

   e_config_save_queue();
   return 1;
}

static Evas_Object *
_basic_create(E_Config_Dialog *cfd EINA_UNUSED, Evas *evas, E_Config_Dialog_Data *cfdata)
{
   Evas_Object *ol, *of2, *ow, *oc;
   Evas_Coord mw, mh;

   e_dialog_resizable_set(cfd->dia, 1);
   ol = e_widget_list_add(evas, 0, 0);

   ow = e_widget_check_add(evas, _("Remember internal dialogs"),
                           &(cfdata->remember_dialogs));
   e_widget_list_object_append(ol, ow, 1, 0, 0.0);
   oc = e_widget_check_add(evas, _("Remember file manager windows"),
                           &(cfdata->remember_fm_wins));
   e_widget_list_object_append(ol, oc, 1, 0, 0.0);
   ow = e_widget_check_add(evas, _("Don't remember file manager windows by directory"),
                           &(cfdata->remember_internal_fm_windows_globally));
   e_widget_check_widget_disable_on_unchecked_add(oc, ow);
   e_widget_list_object_append(ol, ow, 1, 0, 0.0);

   ow = e_widget_ilist_add(evas, 1, 1, NULL);
   cfdata->list = ow;
   e_widget_ilist_multi_select_set(ow, 1);
   e_widget_on_change_hook_set(ow, _cb_list_change, cfdata);
   _fill_remembers(cfdata);

   of2 = e_widget_frametable_add(evas, _("Details"), 0);
   ow = e_widget_label_add(evas, _("Name:"));
   e_widget_size_min_get(ow, &mw, &mh);
   e_widget_frametable_object_append_full
     (of2, ow, 0, 0, 1, 1, 0, 0, 0, 0, 1.0, 1.0, mw, mh, 9999, 9999);
   ow = e_widget_label_add(evas, NULL);
   e_widget_disabled_set(ow, 1);
   cfdata->name = ow;
   e_widget_frametable_object_append(of2, cfdata->name, 1, 0, 1, 1, 1, 1, 1, 0);
   ow = e_widget_label_add(evas, _("Class:"));
   e_widget_size_min_get(ow, &mw, &mh);
   e_widget_frametable_object_append_full
     (of2, ow, 0, 1, 1, 1, 0, 0, 0, 0, 1.0, 1.0, mw, mh, 9999, 9999);
   ow = e_widget_label_add(evas, NULL);
   e_widget_disabled_set(ow, 1);
   cfdata->class = ow;
   e_widget_frametable_object_append(of2, cfdata->class, 1, 1, 1, 1, 1, 1, 1, 0);
   ow = e_widget_label_add(evas, _("Title:"));
   e_widget_size_min_get(ow, &mw, &mh);
   e_widget_frametable_object_append_full
     (of2, ow, 0, 2, 1, 1, 0, 0, 0, 0, 1.0, 1.0, mw, mh, 9999, 9999);
   ow = e_widget_label_add(evas, NULL);
   e_widget_disabled_set(ow, 1);
   cfdata->title = ow;
   e_widget_frametable_object_append(of2, cfdata->title, 1, 2, 1, 1, 1, 1, 1, 0);
   ow = e_widget_label_add(evas, _("Role:"));
   e_widget_size_min_get(ow, &mw, &mh);
   e_widget_frametable_object_append_full
     (of2, ow, 0, 3, 1, 1, 0, 0, 0, 0, 1.0, 1.0, mw, mh, 9999, 9999);
   ow = e_widget_label_add(evas, NULL);
   e_widget_disabled_set(ow, 1);
   cfdata->role = ow;
   e_widget_frametable_object_append(of2, cfdata->role, 1, 3, 1, 1, 1, 1, 1, 0);

   e_widget_list_object_append(ol, cfdata->list, 1, 1, 0.0);
   e_widget_list_object_append(ol, of2, 1, 0, 0.0);

   of2 = e_widget_list_add(evas, 1, 1);

   cfdata->btn = ow = e_widget_button_add(evas, _("Edit"), "edit-rename", _cb_edit, cfdata, NULL);
   e_widget_list_object_append(of2, ow, 1, 1, 0.5);
   cfdata->btn2 = ow = e_widget_button_add(evas, _("Delete"), "list-remove", _cb_delete, cfdata, NULL);
   e_widget_list_object_append(of2, ow, 1, 1, 0.5);
   e_widget_list_object_append(ol, of2, 1, 0, 0.5);

   _cb_list_change(cfdata, NULL);
   return ol;
}

static void
_fill_remembers(E_Config_Dialog_Data *cfdata)
{
   Evas *evas;
   Eina_List *l = NULL;
   Eina_List *ll = NULL;
   Evas_Object *ic;
   int w = 0;

   evas = evas_object_evas_get(cfdata->list);
   evas_event_freeze(evas);
   edje_freeze();
   e_widget_ilist_freeze(cfdata->list);
   e_widget_ilist_clear(cfdata->list);

   ll = eina_list_clone(e_config->remembers);
   ll = eina_list_sort(ll, -1, _cb_sort);

   ic = e_icon_add(evas);
   e_util_icon_theme_set(ic, "preferences-applications");
   e_widget_ilist_header_append(cfdata->list, ic, _("Applications"));

   for (l = ll; l; l = l->next)
     {
        E_Remember *rem = NULL;

        if (!(rem = l->data)) continue;

        /* Filter out E's own remember */
        if ((rem->name) && (!strcmp(rem->name, "E"))) continue;
        /* Filter out the module config remembers */
        if ((rem->class) && (rem->class[0] == '_')) continue;
        if (rem->apply & E_REMEMBER_APPLY_UUID) continue;

        if (rem->name)
          e_widget_ilist_append(cfdata->list, NULL, rem->name, NULL, rem, NULL);
        else if (rem->class)
          e_widget_ilist_append(cfdata->list, NULL, rem->class, NULL, rem, NULL);
        else if (rem->title)
          e_widget_ilist_append(cfdata->list, NULL, rem->title, NULL, rem, NULL);
        else if (rem->role)
          e_widget_ilist_append(cfdata->list, NULL, rem->role, NULL, rem, NULL);
        else
          e_widget_ilist_append(cfdata->list, NULL, "???", NULL, rem, NULL);
     }

   ic = e_icon_add(evas);
   e_util_icon_theme_set(ic, "enlightenment");
   e_widget_ilist_header_append(cfdata->list, ic, _("Enlightenment"));
   for (l = ll; l; l = l->next)
     {
        E_Remember *rem = NULL;

        if (!(rem = l->data)) continue;

        /* Garuntee we add only E's internal remembers */
        if ((!rem->name) || (strcmp(rem->name, "E"))) continue;

        e_widget_ilist_append(cfdata->list, NULL, rem->class, NULL, rem, NULL);
     }

   ic = e_icon_add(evas);
   e_util_icon_theme_set(ic, "preferences-plugin");
   e_widget_ilist_header_append(cfdata->list, ic, _("Modules"));
   for (l = ll; l; l = l->next)
     {
        E_Remember *rem = NULL;

        if (!(rem = l->data)) continue;

        /* Filter out E's own remember */
        if ((!rem->name) || (!strcmp(rem->name, "E"))) continue;
        /* Filter out everything except the module config remembers */
        if ((!rem->class) || (rem->class[0] != '_')) continue;

        e_widget_ilist_append(cfdata->list, NULL, rem->name, NULL, rem, NULL);
     }

   e_widget_ilist_go(cfdata->list);
   e_widget_size_min_get(cfdata->list, &w, NULL);
   if (w < 100 * e_scale)
     w = 100 * e_scale;
   else if (w > 200 * e_scale)
     w = 200 * e_scale;
   e_widget_size_min_set(cfdata->list, w, 150);
   e_widget_ilist_thaw(cfdata->list);
   edje_thaw();
   evas_event_thaw(evas);
   eina_list_free(ll);

   e_widget_disabled_set(cfdata->btn, 1);
}

static void
_cb_edit_del(void *obj)
{
   E_Config_Dialog_Data *cfdata;

   cfdata = e_object_data_get(obj);
   cfdata->cfds = eina_list_remove(cfdata->cfds, obj);
   _fill_remembers(cfdata);
}

static void
_cb_edit(void *data, void *data2 EINA_UNUSED)
{
   E_Config_Dialog_Data *cfdata = data;
   const Eina_List *l;
   E_Ilist_Item *ili;

   EINA_LIST_FOREACH(e_widget_ilist_selected_items_get(cfdata->list), l, ili)
     {
        E_Remember *rem;
        E_Config_Dialog *cfd;

        rem = e_widget_ilist_item_data_get(ili);
        cfd = e_int_client_remember_edit(rem);
        e_object_data_set(E_OBJECT(cfd), cfdata);
        E_OBJECT_DEL_SET(cfd, _cb_edit_del);
        cfdata->cfds = eina_list_append(cfdata->cfds, cfd);
     }
}

static void
_cb_delete(void *data, void *data2 EINA_UNUSED)
{
   E_Config_Dialog_Data *cfdata;
   const Eina_List *l = NULL;
   int i = 0, changed = 0, deleted = 0;
   int last_selected = -1;

   if (!(cfdata = data)) return;
   for (i = 0, l = e_widget_ilist_items_get(cfdata->list); l; l = l->next, i++)
     {
        E_Ilist_Item *item = NULL;
        E_Remember *rem = NULL;

        item = l->data;
        if ((!item) || (!item->selected)) continue;
        if (!(rem = e_widget_ilist_nth_data_get(cfdata->list, i))) continue;
        e_remember_del(rem);
        last_selected = i;
        changed = 1;
        ++deleted;
     }

   if (changed) e_config_save_queue();

   _fill_remembers(cfdata);
   if (last_selected >= 0)
     e_widget_ilist_selected_set(cfdata->list, last_selected - deleted + 1);

   /* This is harmless if an item is being selected by the previous line,
    * and will fill data correctly if there is no window remembers anymore. */
   _cb_list_change(cfdata, NULL);
}

static void
_cb_list_change(void *data, Evas_Object *obj EINA_UNUSED)
{
   E_Config_Dialog_Data *cfdata;
   E_Remember *rem = NULL;
   const Eina_List *selected = NULL;
   E_Ilist_Item *item = NULL;

   if (!(cfdata = data)) return;

   if ((selected = e_widget_ilist_selected_items_get(cfdata->list)))
     {
        if ((item = eina_list_last_data_get(selected)))
          rem = e_widget_ilist_item_data_get(item);
     }

   if (!rem)
     {
        e_widget_label_text_set(cfdata->name, _("No selection"));
        e_widget_disabled_set(cfdata->name, 1);
        e_widget_label_text_set(cfdata->class, _("No selection"));
        e_widget_disabled_set(cfdata->class, 1);
        e_widget_label_text_set(cfdata->title, _("No selection"));
        e_widget_disabled_set(cfdata->title, 1);
        e_widget_label_text_set(cfdata->role, _("No selection"));
        e_widget_disabled_set(cfdata->role, 1);
     }
   else
     {
        e_widget_label_text_set(cfdata->name,
                                rem->name ? rem->name : _("Any"));
        e_widget_disabled_set(cfdata->name, !rem->name);

        e_widget_label_text_set(cfdata->class,
                                rem->class ? rem->class : _("Any"));
        e_widget_disabled_set(cfdata->class, !rem->class);

        e_widget_label_text_set(cfdata->title,
                                rem->title ? rem->title : _("Any"));
        e_widget_disabled_set(cfdata->title, !rem->title);

        e_widget_label_text_set(cfdata->role,
                                rem->role ? rem->role : _("Any"));
        e_widget_disabled_set(cfdata->role, !rem->role);
     }

   if (e_widget_ilist_selected_count_get(cfdata->list) < 1)
     e_widget_disabled_set(cfdata->btn, 1);
   else
     e_widget_disabled_set(cfdata->btn, 0);
}


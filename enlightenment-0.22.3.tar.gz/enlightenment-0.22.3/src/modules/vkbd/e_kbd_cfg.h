#ifndef E_KBD_CFG_H
#define E_KBD_CFG_H

#include "e_kbd_int.h"

EAPI void e_kbd_cfg_show(E_Kbd_Int *ki);
EAPI void e_kbd_cfg_hide(E_Kbd_Int *ki);

#endif

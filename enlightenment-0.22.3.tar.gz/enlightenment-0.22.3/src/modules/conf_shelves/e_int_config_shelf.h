#ifdef E_TYPEDEFS
#else
#ifndef E_INT_CONFIG_SHELF_H
#define E_INT_CONFIG_SHELF_H

E_Config_Dialog *e_int_config_shelf(Evas_Object *parent, const char *params EINA_UNUSED);

#endif
#endif

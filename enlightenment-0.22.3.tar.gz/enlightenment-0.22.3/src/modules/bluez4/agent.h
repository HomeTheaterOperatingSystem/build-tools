#define AGENT_PATH "/org/bluez/Agent"
#define REMOTE_AGENT_PATH "/org/bluez/RemoteAgent"

void ebluez4_register_agent_interfaces(Eldbus_Connection *conn);

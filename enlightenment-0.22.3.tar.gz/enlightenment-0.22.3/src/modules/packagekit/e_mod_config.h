#ifndef PACKAGEKIT_CONFIG_H
#define PACKAGEKIT_CONFIG_H

#include "e_mod_packagekit.h"


void packagekit_config_show(E_PackageKit_Module_Context *ctxt);


#endif

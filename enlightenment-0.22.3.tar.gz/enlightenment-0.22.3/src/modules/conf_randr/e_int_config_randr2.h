#ifdef E_TYPEDEFS
#else
# ifndef E_INT_CONFIG_RANDR2_H
#  define E_INT_CONFIG_RANDR2_H

E_Config_Dialog *e_int_config_randr2(Evas_Object *parent, const char *params);

# endif
#endif

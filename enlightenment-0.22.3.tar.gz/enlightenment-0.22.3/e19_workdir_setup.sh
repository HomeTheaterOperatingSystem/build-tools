export E_MODULE_SRC_PATH=$(readlink -f src/modules/)
export E_START=/e

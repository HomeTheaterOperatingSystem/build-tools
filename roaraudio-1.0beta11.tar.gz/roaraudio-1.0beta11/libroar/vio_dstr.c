//vio_dstr.c:

/*
 *      Copyright (C) Philipp 'ph3-der-loewe' Schafft - 2009-2014
 *
 *  This file is part of libroar a part of RoarAudio,
 *  a cross-platform sound system for both, home and professional use.
 *  See README for details.
 *
 *  This file is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3
 *  as published by the Free Software Foundation.
 *
 *  libroar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; see the file COPYING.  If not, write to
 *  the Free Software Foundation, 51 Franklin Street, Fifth Floor,
 *  Boston, MA 02110-1301, USA.
 *
 *  NOTE for everyone want's to change something and send patches:
 *  read README and HACKING! There a addition information on
 *  the license of this document you need to read before you send
 *  any patches.
 *
 *  NOTE for uses of non-GPL (LGPL,...) software using libesd, libartsc
 *  or libpulse*:
 *  The libs libroaresd, libroararts and libroarpulse link this lib
 *  and are therefore GPL. Because of this it may be illigal to use
 *  them with any software that uses libesd, libartsc or libpulse*.
 */

#include "libroar.h"

#ifndef ROAR_WITHOUT_VIO_DSTR
static struct _roar_vio_dstr_type {
 const int    id;
 const char * name;
 int (* setdef) (struct roar_vio_dstr_chain * cur,   struct roar_vio_dstr_chain * next);
 int (* openvio)(struct roar_vio_calls      * calls, struct roar_vio_calls      * dst, struct roar_vio_dstr_chain * cur, struct roar_vio_dstr_chain * next);
 int    pdeftype[16];
} _roar_vio_dstr_objs[] = {
/*
grep '^#define ROAR_VIO_DSTR_OBJT_' vio_dstr.h | cut -d' ' -f2 | while read objt; do name=`cut -d_ -f5,6,7,8,9,10 <<<$objt | tr A-Z a-z`; echo -e " {$objt,\t \"$name\","; echo "      {ROAR_VIO_DEF_TYPE_EOL}},"; done;
*/
 {ROAR_VIO_DSTR_OBJT_FILE,       "file",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_FH,         "fh",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_FD,         "fd",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SOCKETFH,   "socketfh",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_PASS,       "pass",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_RE,         "re",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_JUMBO,      "jumbo", /* TODO */
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_EXEC,       "exec",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
/* special devices */
 {ROAR_VIO_DSTR_OBJT_NULL,       "null",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_ZERO,       "zero",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_FULL,       "full",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_SOCKET,     "socket",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_UNIX,       "unix",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_DECNET,     "decnet",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_TCP,        "tcp",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_UDP,        "udp",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_TCP6,       "tcp6",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_UDP6,       "udp6",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_SOCKS,      "socks",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SOCKS4,     "socks4",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SOCKS4A,    "socks4a",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SOCKS4D,    "socks4d",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SOCKS5,     "socks5",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SSH,        "ssh",
      roar_vio_proxy_setdef, roar_vio_proxy_openvio,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_HTTP09,     "http09",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_HTTP10,     "http10",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_HTTP11,     "http11",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_HTTP,       "http",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_GOPHER,     "gopher",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_GOPHER_PLUS,"gopher+",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_ICY,        "icy",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_RTP2,       "rtp2",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_RTP,        "rtp",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_GZIP,       "gzip",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_ZLIB,       "zlib",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_BZIP2,      "bzip2",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_PGP,        "pgp",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_PGP_ENC,    "pgp_enc",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_PGP_STORE,  "pgp_store",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SSL1,       "ssl1",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SSL2,       "ssl2",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SSL3,       "ssl3",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_TLS,        "tls",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SSLTLS,     "ssltls",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
/* Random numbers */
 {ROAR_VIO_DSTR_OBJT_NRANDOM,    "nrandom",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_URANDOM,    "urandom",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_SRANDOM,    "srandom",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_TRANSCODE,  "transcode", /* TODO  */
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_RAUM,       "raum",      /* TODO */
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_OGG,        "ogg",       /* TODO */
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_TAR,        "tar",       /* TODO */
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},


 {ROAR_VIO_DSTR_OBJT_MAGIC,      "magic",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_TANTALOS,   "tantalos",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_EOL}},

 {ROAR_VIO_DSTR_OBJT_INTERNAL, "INTERNAL",
      NULL, NULL,
      {ROAR_VIO_DEF_TYPE_FILE, ROAR_VIO_DEF_TYPE_SOCKET, ROAR_VIO_DEF_TYPE_FH, ROAR_VIO_DEF_TYPE_SOCKETFH,
       ROAR_VIO_DEF_TYPE_EOL}},
 {ROAR_VIO_DSTR_OBJT_EOL, NULL, NULL, NULL, {ROAR_VIO_DEF_TYPE_EOL}}
};

int     roar_vio_dstr_get_type(const char * str) {
 int i;

 for (i = 0; _roar_vio_dstr_objs[i].id != ROAR_VIO_DSTR_OBJT_EOL; i++) {
  if ( strcasecmp(_roar_vio_dstr_objs[i].name, str) == 0 )
   return _roar_vio_dstr_objs[i].id;
 }

 return -1;
}

struct _roar_vio_dstr_type * roar_vio_dstr_get_by_type (int type) {
 int i;

 for (i = 0; _roar_vio_dstr_objs[i].id != ROAR_VIO_DSTR_OBJT_EOL; i++) {
  if ( _roar_vio_dstr_objs[i].id == type )
   return &(_roar_vio_dstr_objs[i]);
 }

 return NULL;
}

const char *  roar_vio_dstr_get_name(const int type) {
 struct _roar_vio_dstr_type * ret;

 if ( (ret = roar_vio_dstr_get_by_type(type)) != NULL )
  return ret->name;

 if ( type == ROAR_VIO_DSTR_OBJT_EOL )
  return "<<EOL>>";

 return NULL;
}

int     roar_vio_dstr_register_type(int   type,
                                    char *name,
                                    int (*setdef) (struct roar_vio_dstr_chain * cur,
                                                   struct roar_vio_dstr_chain * next),
                                    int (*openvio)(struct roar_vio_calls      * calls,
                                                   struct roar_vio_calls      * dst,
                                                   struct roar_vio_dstr_chain * cur,
                                                   struct roar_vio_dstr_chain * next)) {
 struct _roar_vio_dstr_type * ret;

 if ( (ret = roar_vio_dstr_get_by_type(type)) == NULL ) /* we can currently not register new types */
  return -1;


 // check if things are allready set, we do not want to allow overwrite here.
 if ( setdef != NULL && ret->setdef != NULL )
  return -1;

 if ( openvio != NULL && ret->openvio != NULL )
  return -1;

 if ( setdef != NULL )
  ret->setdef = setdef;

 if ( openvio != NULL )
  ret->openvio = openvio;

 return 0;
}

static void _roar_vio_dstr_init_otherlibs (void) {
 roar_dl_ra_init(ROAR_DL_HANDLE_DEFAULT, "libroardsp",   NULL);
 roar_dl_ra_init(ROAR_DL_HANDLE_DEFAULT, "libroareio",   NULL);
 roar_dl_ra_init(ROAR_DL_HANDLE_DEFAULT, "libroarlight", NULL);
 roar_dl_ra_init(ROAR_DL_HANDLE_DEFAULT, "libroarmidi",  NULL);
}

#endif

int     roar_vio_dstr_init_defaults (struct roar_vio_defaults * def, int type, int o_flags, mode_t o_mode) {
 if ( def == NULL )
  return -1;

 memset(def, 0, sizeof(struct roar_vio_defaults));

 def->type    = type;
 def->o_flags = o_flags;
 def->o_mode  = o_mode;

 return 0;
}

int     roar_vio_dstr_init_defaults_c (struct roar_vio_defaults * def, int type, struct roar_vio_defaults * odef, int o_flags) {
 if ( o_flags < 1 )
  o_flags = O_RDONLY;

 if ( odef == NULL ) {
  return roar_vio_dstr_init_defaults(def, type, o_flags, 0644);
 } else {
  return roar_vio_dstr_init_defaults(def, type, odef->o_flags, odef->o_mode);
 }
}

#ifndef ROAR_WITHOUT_VIO_DSTR
#ifdef ROAR_HAVE_IO_POSIX
static int _open_file(struct roar_vio_calls * calls, const char * filename, int flags, mode_t mode) {
 int fh;

 if ( calls == NULL || filename == NULL ) {
  roar_err_set(ROAR_ERROR_FAULT);
  return -1;
 }

#ifdef ROAR_TARGET_WIN32
 flags |= O_BINARY;
#endif

 ROAR_DBG("_open_file(calls=%p, filename='%s', flags=0x%x, mode=%i) = ?", calls, filename, flags, (int)mode);
 roar_err_clear_all();
 if ( (fh = open(filename, flags, mode)) == -1 ) {
  roar_err_update();
  return -1;
 }

 if ( roar_vio_open_fh(calls, fh) == -1 ) {
  close(fh);
  roar_err_to_errno();
  return -1;
 }

 roar_err_update();
 return 0;
}
#endif

int     roar_vio_open_default (struct roar_vio_calls * calls, struct roar_vio_defaults * def, char * opts) {
 ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s') = ?", calls, def, opts);

 if ( calls == NULL || def == NULL ) {
  roar_err_set(ROAR_ERROR_FAULT);
  return -1;
 }

 switch (def->type) {
  case ROAR_VIO_DEF_TYPE_NONE:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s'): def->type=%i, dummy open", calls, def, opts, (int)def->type);
   break;
#ifdef ROAR_HAVE_IO_POSIX
  case ROAR_VIO_DEF_TYPE_FILE:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s'): def->type=%i, file open", calls, def, opts, (int)def->type);
    if ( _open_file(calls, def->d.file, def->o_flags, def->o_mode) == -1 ) {
     ROAR_DBG("roar_vio_open_default(*): Can not open file: %i", roar_error);
     return -1;
    }
   break;
#endif
  case ROAR_VIO_DEF_TYPE_SOCKET:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s'): def->type=%i, socket open", calls, def, opts, (int)def->type);
     if ( roar_vio_open_def_socket(calls, def, opts) == -1 )
      return -1;
   break;
  case ROAR_VIO_DEF_TYPE_FH:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s'): def->type=%i, fh open", calls, def, opts, (int)def->type);
    if ( roar_vio_open_fh(calls, def->d.fh) == -1 )
     return -1;
   break;
  case ROAR_VIO_DEF_TYPE_SOCKETFH:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s'): def->type=%i, socket fh open", calls, def, opts, (int)def->type);
    if ( roar_vio_open_fh_socket(calls, def->d.fh) == -1 )
     return -1;
   break;
  default:
    ROAR_DBG("roar_vio_open_default(calls=%p, def=%p, opts='%s') = -1 // error=NOTSUP", calls, def, opts);
    roar_err_set(ROAR_ERROR_NOTSUP);
    return -1;
 }

 return 0;
}
#endif

int     roar_vio_open_dstr_simple(struct roar_vio_calls * calls, const char * dstr, int o_flags) {
 struct roar_vio_defaults def;

 if ( roar_vio_dstr_init_defaults(&def, ROAR_VIO_DEF_TYPE_NONE, o_flags, 0644) == -1 )
  return -1;

 if ( roar_vio_open_dstr_vio(calls, dstr, &def, 1, NULL) == -1 )
  return -1;

 return 0;
}

struct roar_vio_calls * roar_vio_open_dstr_simple_new(const char * dstr, int o_flags) {
 struct roar_vio_calls * ret = roar_mm_malloc(sizeof(struct roar_vio_calls));
 int err;

 if ( ret == NULL )
  return NULL;

 if ( roar_vio_open_dstr_simple(ret, dstr, o_flags) == -1 ) {
  err = roar_error;
  roar_mm_free(ret);
  roar_error = err;
  return NULL;
 }

 ret->flags |= ROAR_VIO_FLAGS_FREESELF;

 return ret;
}

int     roar_vio_open_dstr    (struct roar_vio_calls * calls, const char * dstr, struct roar_vio_defaults * def, int dnum) {
 return roar_vio_open_dstr_vio(calls, dstr, def, dnum, NULL);
}

#define _ret(x) do { int _err = roar_error; roar_mm_free(dstr_copy); roar_error = _err; roar_err_to_errno(); return (x); } while (0)

int     roar_vio_open_dstr_vio(struct roar_vio_calls * calls,
                               const char * dstr, struct roar_vio_defaults * def, int dnum,
                               struct roar_vio_calls * vio) {
#ifndef ROAR_WITHOUT_VIO_DSTR
 struct roar_vio_dstr_chain chain[ROAR_VIO_DSTR_MAX_OBJ_PER_CHAIN];
 char * dstr_copy;
 char * next;
 char * this;
 char * name;
 char * opts;
 char * dst;
 char * c;
 int    inopts;
 int    type;
 int    cc = 1; // current chain element

 if ( calls == NULL || dstr == NULL )
  return -1;

 if ( dnum != 0 && def == NULL )
  return -1;

 if ( (dstr_copy = roar_mm_strdup(dstr)) == NULL )
  return -1;

 memset(chain, 0, sizeof(chain));

 chain[0].type = ROAR_VIO_DSTR_OBJT_INTERNAL;

 next = dstr_copy;

 while (next != NULL) {
  if ( (cc+1) == ROAR_VIO_DSTR_MAX_OBJ_PER_CHAIN ) {
   _ret(-1);
  }

  this = next;
  next = strstr(next, "##");

  if (next != NULL) {
   *next = 0;
   next += 2;
  }

  // we have the current token in 'this'.

  opts   = NULL;
  dst    = NULL;

  if ( strstr(this, ":") != NULL ) {
   name   = this;
   inopts = 0;
   for (c = this; *c != 0; c++) {
    if ( *c == '[' ) {
     *c     = 0;
     opts   = c + 1;
     inopts = 1;
    } else if ( *c == ']' &&  inopts ) {
     *c     = 0;
     inopts = 0;
    } else if ( *c == ':' && !inopts ) {
     *c     = 0;
     dst    = *(c+1) == 0 ? NULL : c + 1;
     break;
    }
   }
  } else {
   // we need to guess that this is here...
   // currently we guess this is a file in all cases
   name = "file";
   dst  = this;
  }

  ROAR_DBG("roar_vio_open_dstr_vio(*): name='%s', opts='%s', dst='%s'", name, opts, dst);

  if ( (type = roar_vio_dstr_get_type(name)) == -1 ) {
   _ret(-1);
  }

  ROAR_DBG("roar_vio_open_dstr_vio(*): type=0x%.4x(%s)", type, roar_vio_dstr_get_name(type));

  chain[cc].type     = type;
  chain[cc].opts     = opts;
  chain[cc].dst      = dst;
  chain[cc].def      = NULL;
  chain[cc].vio      = NULL;
  chain[cc].need_vio = -1;
  cc++;

 }

 chain[cc].type = ROAR_VIO_DSTR_OBJT_EOL;

 ROAR_DBG("roar_vio_open_dstr_vio(*): chain=%p", chain);

 if ( roar_vio_dstr_parse_opts(chain) == -1 ) {
  _ret(-1);
 }

 if ( roar_vio_dstr_set_defaults(chain, cc, def, dnum) == -1 ) {
  _ret(-1);
 }

 if ( roar_vio_dstr_build_chain(chain, calls, vio) == -1 ) {
  _ret(-1);
 }

 _ret(0);
#else
 return -1;
#endif
}

#undef _ret

#ifndef ROAR_WITHOUT_VIO_DSTR
int     roar_vio_dstr_parse_opts(struct roar_vio_dstr_chain * chain) {
 if ( chain == NULL )
  return -1;

 // TODO: we should add some code here later...

 return 0;
}

int     roar_vio_dstr_set_defaults(struct roar_vio_dstr_chain * chain, int len, struct roar_vio_defaults * def, int dnum) {
 struct _roar_vio_dstr_type * type;
 struct roar_vio_dstr_chain * c, * next;
 int i;
 int tmp[8];

 if ( chain == NULL )
  return -1;

 if ( def == NULL && dnum != 0 )
  return -1;

 if ( dnum > 1 ) /* currently not supported */
  return -1;

 if ( dnum == 0 )
  def = NULL;

 chain[len].def = def;

 for (i = len; i >= 0; i--) {
  c    = &chain[i];

  if ( i > 0 ) {
   next = &chain[i-1];
  } else {
   next = NULL;

   if ( c->type != ROAR_VIO_DSTR_OBJT_INTERNAL )
    return -1;
  }

  memset(tmp, 0, sizeof(tmp));

  ROAR_DBG("roar_vio_dstr_set_defaults(*): i=%i, c->type=0x%.4x(%s)", i, c->type & 0xFFFF, roar_vio_dstr_get_name(c->type));
  ROAR_DBG("roar_vio_dstr_set_defaults(*): i=%i, c->type=0x%.4x(%s): c->def=%p, c->def->type=%i", i, c->type & 0xFFFF,
                   roar_vio_dstr_get_name(c->type), c->def, c->def == NULL ? -1 : c->def->type);

  c->need_vio = 1;

  switch (c->type) {
   case ROAR_VIO_DSTR_OBJT_INTERNAL:
     c->need_vio = 0;
    break;
   case ROAR_VIO_DSTR_OBJT_EOL:
     tmp[0] = 1;
   case ROAR_VIO_DSTR_OBJT_PASS:
   case ROAR_VIO_DSTR_OBJT_RE:
   case ROAR_VIO_DSTR_OBJT_RTP2: // we currently only forward the defs
   case ROAR_VIO_DSTR_OBJT_GZIP:
   case ROAR_VIO_DSTR_OBJT_ZLIB:
   case ROAR_VIO_DSTR_OBJT_BZIP2:
   case ROAR_VIO_DSTR_OBJT_PGP:
   case ROAR_VIO_DSTR_OBJT_PGP_ENC:
   case ROAR_VIO_DSTR_OBJT_PGP_STORE:
   case ROAR_VIO_DSTR_OBJT_SSL1:
   case ROAR_VIO_DSTR_OBJT_SSL2:
   case ROAR_VIO_DSTR_OBJT_SSL3:
   case ROAR_VIO_DSTR_OBJT_TLS:
   case ROAR_VIO_DSTR_OBJT_MAGIC:
     if ( tmp[0] )
      c->need_vio = 0;

     next->def = c->def;
    break;
   case ROAR_VIO_DSTR_OBJT_NULL:
   case ROAR_VIO_DSTR_OBJT_ZERO:
   case ROAR_VIO_DSTR_OBJT_FULL:
   case ROAR_VIO_DSTR_OBJT_NRANDOM:
   case ROAR_VIO_DSTR_OBJT_TANTALOS:
     next->def = &(next->store_def);
     roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_NONE, NULL, -1);
    break;
   case ROAR_VIO_DSTR_OBJT_FILE:
     if ( c->dst == NULL ) /* should we allow multible cascaed file: objects? */
      return -1;

     c->need_vio = 0;
     next->def = &(next->store_def);
     roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_FILE, c->def, -1);

     if ( c->dst[0] == '/' && c->dst[1] == '/' ) {
      next->def->d.file = c->dst + 1;
     } else {
      next->def->d.file = c->dst;
     }
    break;
   case ROAR_VIO_DSTR_OBJT_FH:
     tmp[0] = 1;
   case ROAR_VIO_DSTR_OBJT_SOCKETFH:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( c->def != NULL ) {
      tmp[2] = c->def->o_flags;
      tmp[3] = c->def->o_mode;
     } else {
      tmp[2] = O_RDONLY;
      tmp[3] = 0644;
     }

     if ( !strcasecmp(c->dst, "stdin") ) {
      tmp[1] = ROAR_STDIN;
      tmp[2] = O_RDONLY;
     } else if ( !strcasecmp(c->dst, "stdout") ) {
      tmp[1] = ROAR_STDOUT;
      tmp[2] = O_WRONLY;
     } else if ( !strcasecmp(c->dst, "stderr") ) {
      tmp[1] = ROAR_STDERR;
      tmp[2] = O_WRONLY;
     } else {
      if ( sscanf(c->dst, "%i", &tmp[1]) != 1 )
       return -1;
     }

     roar_vio_dstr_init_defaults(next->def, tmp[0] ? ROAR_VIO_DEF_TYPE_FH : ROAR_VIO_DEF_TYPE_SOCKETFH, tmp[2], tmp[3]);
     next->def->d.fh = tmp[1];
    break;
#ifdef ROAR_HAVE_UNIX
   case ROAR_VIO_DSTR_OBJT_UNIX:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( c->dst == NULL ) { // we don't have a destination? -> slow way
      if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
       return -1;

      if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_UNIX, SOCK_STREAM, c->def) == -1 )
       return -1;
     } else {                // we have a destination? -> fast way
      if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
       return -1;

      if ( roar_vio_socket_init_unix_def(next->def, c->dst) == -1 )
       return -1;
     }
    break;
#endif
   case ROAR_VIO_DSTR_OBJT_SOCKET:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, -1, SOCK_STREAM, c->def) == -1 )
      return -1;
    break;
#ifdef ROAR_HAVE_LIBDNET
   case ROAR_VIO_DSTR_OBJT_DECNET:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_DECnet, SOCK_STREAM, c->def) == -1 )
      return -1;
    break;
#endif
#ifdef ROAR_HAVE_IPV4
   case ROAR_VIO_DSTR_OBJT_TCP:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_INET, SOCK_STREAM, c->def) == -1 )
      return -1;
    break;
   case ROAR_VIO_DSTR_OBJT_UDP:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_INET, SOCK_DGRAM, c->def) == -1 )
      return -1;
    break;
#endif
#ifdef ROAR_HAVE_IPV6
   case ROAR_VIO_DSTR_OBJT_TCP6:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_INET6, SOCK_STREAM, c->def) == -1 )
      return -1;
    break;
   case ROAR_VIO_DSTR_OBJT_UDP6:
     c->need_vio = 0;
     next->def = &(next->store_def);

     if ( roar_vio_dstr_init_defaults_c(next->def, ROAR_VIO_DEF_TYPE_SOCKET, c->def, O_WRONLY) == -1 )
      return -1;

     if ( roar_vio_socket_init_dstr_def(next->def, c->dst, AF_INET6, SOCK_DGRAM, c->def) == -1 )
      return -1;
    break;
#endif
   case ROAR_VIO_DSTR_OBJT_HTTP09:
   case ROAR_VIO_DSTR_OBJT_HTTP10:
   case ROAR_VIO_DSTR_OBJT_HTTP11:
     c->need_vio = 1;
     next->def = &(next->store_def);

     if ( roar_vio_proto_init_def(next->def, c->dst, ROAR_VIO_PROTO_P_HTTP, c->def) == -1 )
      return -1;
    break;
   case ROAR_VIO_DSTR_OBJT_GOPHER:
   case ROAR_VIO_DSTR_OBJT_GOPHER_PLUS:
     c->need_vio = 1;
     next->def = &(next->store_def);

     if ( roar_vio_proto_init_def(next->def, c->dst, ROAR_VIO_PROTO_P_GOPHER, c->def) == -1 )
      return -1;
    break;
   case ROAR_VIO_DSTR_OBJT_ICY:
     c->need_vio = 1;
     next->def = &(next->store_def);

     if ( roar_vio_proto_init_def(next->def, c->dst, ROAR_VIO_PROTO_P_ICY, c->def) == -1 )
      return -1;
    break;
   default:
     if ( (type = roar_vio_dstr_get_by_type(c->type)) == NULL ) {
      return -1;
     }

     if ( type->setdef == NULL )
      _roar_vio_dstr_init_otherlibs();

     if ( type->setdef == NULL ) {
      return -1;
     }

     if ( type->setdef(c, next) == -1 ) {
      return -1;
     }
  }

  if ( next != NULL ) {
   ROAR_DBG("roar_vio_dstr_set_defaults(*): i=%i, c->type=0x%.4x(%s): next->def=%p, next->def->type=%i", i,
                    c->type & 0xFFFF, roar_vio_dstr_get_name(c->type),
                    next->def, next->def == NULL ? -1 : next->def->type);
   if ( next->def != NULL ) {
    ROAR_DBG("roar_vio_dstr_set_defaults(*): i=%i, c->type=0x%.4x(%s): next->def->o_flags=%i", i,
                     c->type & 0xFFFF, roar_vio_dstr_get_name(c->type),
                     next->def->o_flags);
   }
  } else {
   ROAR_DBG("roar_vio_dstr_set_defaults(*): i=%i, c->type=0x%.4x(%s): next=NULL", i,
                    c->type & 0xFFFF, roar_vio_dstr_get_name(c->type));
  }
 }

 ROAR_DBG("roar_vio_dstr_set_defaults(*) = 0");

 return 0;
}

#define _ret(x) do { int _err = roar_error; roar_vio_close(calls); roar_error = _err; roar_err_to_errno(); ROAR_DBG("roar_vio_dstr_build_chain(*) = %i", (x)); return (x); } while(0)

int     roar_vio_dstr_build_chain(struct roar_vio_dstr_chain * chain, struct roar_vio_calls * calls,
                                  struct roar_vio_calls * vio) {
 struct _roar_vio_dstr_type * type;
 struct roar_vio_dstr_chain * c;
 struct roar_vio_defaults   * def;
 struct roar_vio_calls      * tc, * prev;
 int i;

 ROAR_DBG("roar_vio_dstr_build_chain(*) = ?");

 if ( chain == NULL || calls == NULL )
  return -1;

 if ( roar_vio_open_stack2(calls, NULL) == -1 )
  return -1;

 ROAR_DBG("roar_vio_dstr_build_chain(*): chain=%p", chain);

 if ( (def = chain->def) != NULL ) {
  if ( (tc = roar_mm_malloc(sizeof(struct roar_vio_calls))) == NULL ) {
   _ret(-1);
  }

  if ( roar_vio_clear_calls(tc) == -1 ) {
   roar_mm_free(tc);
   _ret(-1);
  }

  if ( roar_vio_stack_add(calls, tc) == -1 ) {
   _ret(-1);
  }

  if ( chain->opts == NULL ) {
   if ( chain[1].type != ROAR_VIO_DSTR_OBJT_EOL ) {
    chain->opts = chain[1].opts;
   }
  }

  if ( roar_vio_open_default(tc, def, chain->opts) == -1 ) {
   _ret(-1);
  }

  prev = tc;
 } else {
  prev = vio;
 }

 for (i = 0; (c = &(chain[i]))->type != ROAR_VIO_DSTR_OBJT_EOL; i++) {
  ROAR_DBG("roar_vio_dstr_build_chain(*): i=%i, c->type=0x%.4x(%s): need_vio=%i, def(%p)->o_flags=%i", i,
                   c->type & 0xFFFF, roar_vio_dstr_get_name(c->type), c->need_vio, c->def, c->def != NULL ? c->def->o_flags : -1);

  if ( c->need_vio ) {
   if ( (tc = roar_mm_malloc(sizeof(struct roar_vio_calls))) == NULL ) {
    _ret(-1);
   }

   if ( roar_vio_clear_calls(tc) == -1 ) {
    roar_mm_free(tc);
    _ret(-1);
   }

   if ( roar_vio_stack_add(calls, tc) == -1 ) {
    _ret(-1);
   }


   switch (c->type) {
    case ROAR_VIO_DSTR_OBJT_PASS:
      if ( roar_vio_open_pass(tc, prev) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_RE:
      if ( roar_vio_open_re(tc, prev) == -1 ) {
       _ret(-1);
      }
     break;
#ifdef ROAR_HAVE_LIBZ
    case ROAR_VIO_DSTR_OBJT_GZIP:
      if ( roar_vio_open_zlib(tc, prev, -1, 1) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_ZLIB:
      if ( roar_vio_open_zlib(tc, prev, -1, 0) == -1 ) {
       _ret(-1);
      }
     break;
#endif
    case ROAR_VIO_DSTR_OBJT_BZIP2:
    case ROAR_VIO_DSTR_OBJT_PGP:
      if ( roar_vio_open_pgp_decrypt(tc, prev, NULL) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_HTTP09:
    case ROAR_VIO_DSTR_OBJT_HTTP10:
    case ROAR_VIO_DSTR_OBJT_HTTP11:
      if ( roar_vio_open_proto(tc, prev, c->dst, ROAR_VIO_PROTO_P_HTTP, c->def) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_GOPHER:
    case ROAR_VIO_DSTR_OBJT_GOPHER_PLUS:
      if ( roar_vio_open_proto(tc, prev, c->dst, ROAR_VIO_PROTO_P_GOPHER, c->def) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_ICY:
      if ( roar_vio_open_proto(tc, prev, c->dst, ROAR_VIO_PROTO_P_ICY, c->def) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_RTP2:
      if ( roar_vio_open_rtp(tc, prev, c->dst, c->def) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_PGP_ENC:
    case ROAR_VIO_DSTR_OBJT_PGP_STORE:
      if ( roar_vio_open_pgp_store(tc, prev, ROAR_VIO_PGP_OPTS_NONE) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_TANTALOS:
      if ( roar_vio_open_tantalos(tc, prev, c->dst, c->def) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_NULL:
    case ROAR_VIO_DSTR_OBJT_ZERO:
    case ROAR_VIO_DSTR_OBJT_FULL:
    case ROAR_VIO_DSTR_OBJT_NRANDOM:
      if ( roar_vio_open_misc_by_name(tc, roar_vio_dstr_get_name(c->type)) == -1 ) {
       _ret(-1);
      }
     break;
    case ROAR_VIO_DSTR_OBJT_SSL1:
    case ROAR_VIO_DSTR_OBJT_SSL2:
    case ROAR_VIO_DSTR_OBJT_SSL3:
    case ROAR_VIO_DSTR_OBJT_TLS:
    case ROAR_VIO_DSTR_OBJT_MAGIC:
      _ret(-1);
     break;
    default:
      if ( (type = roar_vio_dstr_get_by_type(c->type)) == NULL ) {
       _ret(-1);
      }

      if ( type->openvio == NULL )
       _roar_vio_dstr_init_otherlibs();

      if ( type->openvio == NULL ) {
       _ret(-1);
      }

      if ( type->openvio(tc, prev, c, &(chain[i+1])) == -1 ) {
       _ret(-1);
      }
   }

   prev = tc;
  } // else we can skip to the next :)
 }

 ROAR_DBG("roar_vio_dstr_build_chain(*) = 0");
 return 0;
}

#undef _ret

static inline ssize_t __libroar_dir_part_len(char * p, size_t len) {
 ssize_t i, c;

 c = -1;

 for (i = 0; i < len; i++, p++)
  if ( *p == '/' )
   c = i;

 return c;
}

char *  roar_vio_dstr_cat(char * buffer, ssize_t bufferlen, const struct roar_vio_dstr_pathelement * elements, size_t elementslen) {
 size_t needed = 0;
 size_t rootelement = 0;
 ssize_t ret;
 char * p;
 size_t i;

 if ( buffer == NULL )
  bufferlen = -1;

 if ( elementslen == 0 ) {
  if ( bufferlen == -1 ) {
   if ( (buffer = roar_mm_malloc(2)) == NULL )
    return NULL;
   bufferlen = 2;
  }

  if ( bufferlen >= 2 ) {
   buffer[0] = '.';
   buffer[1] = 0;
   return buffer;
  } else {
   roar_err_set(ROAR_ERROR_NOSPC);
   return NULL;
  }
 }

 if ( elements == NULL ) {
  roar_err_set(ROAR_ERROR_FAULT);
  return NULL;
 }

 for (i = 0; i < elementslen; i++) {
  if ( elements[i].dstr == NULL ) {
   roar_err_set(ROAR_ERROR_FAULT);
   return NULL;
  }

  if ( !(elements[i].flags & ROAR_VIO_DSTR_PEF_ALLOW_MULTI) && strstr(elements[i].dstr, "##") != NULL ) {
   roar_err_set(ROAR_ERROR_INVAL);
   return NULL;
  }

  if ( !(elements[i].flags & ROAR_VIO_DSTR_PEF_ALLOW_PARENT) && strstr(elements[i].dstr, "..") != NULL ) {
   roar_err_set(ROAR_ERROR_INVAL);
   return NULL;
  }

  if ( strstr(elements[i].dstr, "##") != NULL ) {
   roar_err_set(ROAR_ERROR_NOTSUP);
   return NULL;
  }

  if ( strstr(elements[i].dstr, ":") != NULL ) {
   if ( !(elements[i].flags & ROAR_VIO_DSTR_PEF_ALLOW_ABSOLUTE) ) {
    roar_err_set(ROAR_ERROR_INVAL);
    return NULL;
   }
   rootelement = i;
   needed = 0;
  }

  needed += roar_mm_strlen(elements[i].dstr);
 }

 elements += rootelement;
 elementslen -= rootelement;

 if ( elementslen == 1 ) {
  if ( bufferlen == -1 ) {
   bufferlen = needed+1;
   if ( (buffer = roar_mm_malloc(bufferlen)) == NULL )
    return NULL;
  }

  if ( bufferlen >= (elementslen + 1) ) {
   memcpy(buffer, elements[0].dstr, needed+1);
   return buffer;
  } else {
   roar_err_set(ROAR_ERROR_NOSPC);
   return NULL;
  }
 }

 needed += elementslen * 2; // for '.', '/' and '\0'.

 if ( bufferlen == -1 ) {
  bufferlen = needed;
  if ( (buffer = roar_mm_malloc(bufferlen)) == NULL )
   return NULL;
 }

 if ( bufferlen < needed ) {
  roar_err_set(ROAR_ERROR_NOSPC);
  return NULL;
 }

 p = buffer;
 for (i = 0; i < elementslen; i++) {
  ret = roar_mm_strlen(elements[i].dstr);
  memcpy(p, elements[i].dstr, ret);
  if ( i == (elementslen-1) || elements[i].flags & ROAR_VIO_DSTR_PEF_IS_DIR ) {
   p += ret;
  } else {
   ret = __libroar_dir_part_len(p, ret);
   if ( ret == -1 ) {
    *p = '.';
    p++;
   } else {
    p += ret;
   }
  }

  *p = '/';
  p++;
 }

 p--;
 *p = 0;
 return buffer;
}
#endif

//ll

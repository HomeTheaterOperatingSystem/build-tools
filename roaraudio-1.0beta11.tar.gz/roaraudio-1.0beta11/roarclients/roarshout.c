//roarshout.c:

/*
 *      Copyright (C) Philipp 'ph3-der-loewe' Schafft - 2008-2014
 *
 *  This file is part of roarclients a part of RoarAudio,
 *  a cross-platform sound system for both, home and professional use.
 *  See README for details.
 *
 *  This file is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3
 *  as published by the Free Software Foundation.
 *
 *  RoarAudio is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; see the file COPYING.  If not, write to
 *  the Free Software Foundation, 51 Franklin Street, Fifth Floor,
 *  Boston, MA 02110-1301, USA.
 *
 */

#include <roaraudio.h>

#ifdef ROAR_HAVE_LIBSHOUT
#include <shout/shout.h>

#define BUFSIZE 2048

void usage (void) {
 printf("roarshout [OPTIONS]... [address [port [password [mountpoint]]]\n");

 printf("\nRoarAudio Options:\n\n");

 printf("    --server SERVER    - Set server hostname\n"
        " -R --rate   RATE      - Set sample rate\n"
        " -B --bits   BITS      - Set bits per sample\n"
        " -C --chans  CHANNELS  - Set number of channels\n"
        " -E --codec  CODEC     - Set the codec\n"
        "    --aiprofile PROFILE\n"
        "                       - Set audio profile\n"
        " -h --help             - Show this help\n"
        "    --pw-arg           - Password is supplied as argument (default).\n"
        "    --pw-ask           - Ask user for password interactively.\n"
        "    --pw-dstr          - Read password from file. Filename is supplied\n"
        "                         as normal password argument.\n"
       );

 printf("\nlibshout Options:\n\n");

 printf(" -p --public           - Allow listing in stream directory\n"
        " -d          DESC      - Set stream description\n"
        " -g          GENRE     - Set stream genre\n"
        " -n          NAME      - Set stream name\n"
        " -u          URL       - Set stream URL/homepage\n"
       );

}

char * read_pw_from_file(char * filename, char * buffer, size_t bufferlen) {
 struct roar_vio_defaults def;
 struct roar_vio_calls file;
 ssize_t len;

 if (filename == NULL || buffer == NULL)
  return NULL;

 if ( roar_vio_dstr_init_defaults(&def, ROAR_VIO_DEF_TYPE_NONE, O_RDONLY, 0644) == -1 )
  return NULL;

 if ( roar_vio_open_dstr(&file, filename, &def, 1) == -1 )
  return NULL;

 len = roar_vio_read(&file, buffer, bufferlen - 1);

 if ( len == -1 )
  return NULL;

 // strip newlions.
 for (; buffer[len-1] == '\r' || buffer[len-1] == '\n'; len--);

 buffer[len] = 0;

 roar_vio_close(&file);

 return buffer;
}

int main (int argc, char * argv[]) {
 enum { ARG, ASK, DSTR } pw_source = ARG;
 struct roar_audio_info info;
 const char * server   = NULL;
 const char * k;
 const char * s_server = NULL;
 const char * s_mount  = NULL;
 char * s_pw     = NULL;
 int    s_port   = -1;
 const char * s_desc   = NULL;
 const char * s_genre  = NULL;
 const char * s_name   = NULL;
 const char * s_url    = NULL;
 int    s_public = 0;
 roar_vs_t * vss;
 int    err;
 ssize_t ret;
 int    i;
 char buf[BUFSIZE];
 shout_t * shout;
 char password_buf[128];

 if ( roar_profile2info(&info, "default") == -1 )
  return 1;

 info.codec = ROAR_CODEC_OGG_VORBIS;

 for (i = 1; i < argc; i++) {
  k = argv[i];

  if ( strcmp(k, "--server") == 0 ) {
   ROAR_CKHAVEARGS(1);
   server = argv[++i];
  } else if ( strcmp(k, "--rate") == 0 || strcmp(k, "-R") == 0 ) {
   ROAR_CKHAVEARGS(1);
   info.rate = roar_str2rate(argv[++i]);
  } else if ( strcmp(k, "--bits") == 0 || strcmp(k, "-B") == 0 ) {
   ROAR_CKHAVEARGS(1);
   info.bits = roar_str2bits(argv[++i]);
  } else if ( strcmp(k, "--channels") == 0 || strcmp(k, "--chans") == 0 || strcmp(k, "-C") == 0 ) {
   ROAR_CKHAVEARGS(1);
   info.channels = roar_str2channels(argv[++i]);
  } else if ( strcmp(k, "--codec") == 0 || strcmp(k, "-E") == 0 ) {
   ROAR_CKHAVEARGS(1);
   info.codec = roar_str2codec(argv[++i]);
  } else if ( !strcmp(k, "--aiprofile") ) {
   ROAR_CKHAVEARGS(1);
   if ( roar_profile2info(&info, argv[++i]) == -1 ) {
    fprintf(stderr, "Error: Can not load audio profile: %s: %s\n", argv[i], roar_error2str(roar_error));
    return 1;
   }
  } else if ( strcmp(k, "--pw-arg") == 0 ) {
   pw_source = ARG;
  } else if ( strcmp(k, "--pw-ask") == 0 ) {
   pw_source = ASK;
  } else if ( strcmp(k, "--pw-dstr") == 0 ) {
   pw_source = DSTR;
  } else if ( strcmp(k, "-p") == 0 || strcmp(k, "--public") == 0 ) {
   s_public = 1;
  } else if ( strcmp(k, "-d") == 0 ) {
   ROAR_CKHAVEARGS(1);
   s_desc   = argv[++i];
  } else if ( strcmp(k, "-g") == 0 ) {
   ROAR_CKHAVEARGS(1);
   s_genre  = argv[++i];
  } else if ( strcmp(k, "-n") == 0 ) {
   ROAR_CKHAVEARGS(1);
   s_name   = argv[++i];
  } else if ( strcmp(k, "-u") == 0 ) {
   ROAR_CKHAVEARGS(1);
   s_url    = argv[++i];
  } else if ( strcmp(k, "-h") == 0 || strcmp(k, "--help") == 0 ) {
   usage();
   return 0;
  } else if ( s_server == NULL ) {
   ROAR_CKHAVEARGS(1);
   s_server = k;
  } else if ( s_port   == -1 ) {
   ROAR_CKHAVEARGS(1);
   s_port   = atoi(k);
  } else if ( s_pw     == NULL ) {
   ROAR_CKHAVEARGS(1);
   s_pw     = argv[i]; // do not use k here so k can be const.
  } else if ( s_mount  == NULL ) {
   ROAR_CKHAVEARGS(1);
   s_mount  = k;
  } else {
   fprintf(stderr, "Error: unknown argument: %s\n", k);
   usage();
   return 1;
  }
 }

 switch (pw_source) {
  case ARG:
    // nothing to do
   break;
  case ASK:
    if ( roar_passwd_simple_ask_pw(&s_pw, "Password for icecast server?", NULL) == -1 ) {
     fprintf(stderr, "Error: unabled to read password from user.\n");
     return 1;
    }
    strncpy(password_buf, s_pw, sizeof(password_buf)-1);
    roar_mm_free(s_pw);
    password_buf[sizeof(password_buf)-2] = 0;
    s_pw = password_buf;
   break;
  case DSTR:
    if ( (s_pw = read_pw_from_file(s_pw, password_buf, sizeof(password_buf))) == NULL ) {
     fprintf(stderr, "Error: unabled to read password from file.\n");
     return 1;
    }
   break;
 }

 if ( s_server == NULL )
  s_server = "localhost";

 if ( s_mount == NULL )
  s_mount  = "/roar.ogg";

 if ( s_pw == NULL )
  s_pw     = "hackme";

 if ( s_port == -1 )
  s_port   = 8000;

 if ( !strcasecmp(s_pw, "hackme") ) {
  fprintf(stderr, "Warning: Your password is very weak. Change it!\n");
 }

 shout_init();

 if (!(shout = shout_new())) {
  ROAR_ERR("Can not create shout object");
  return 1;
 }

 if (shout_set_host(shout, s_server) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting hostname: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_protocol(shout, SHOUT_PROTOCOL_HTTP) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting protocol: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_port(shout, s_port) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting port: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_password(shout, s_pw) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting password: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_mount(shout, s_mount) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting mount: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_user(shout, "source") != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting user: %s", shout_get_error(shout));
  return 1;
 }

 if (shout_set_format(shout, SHOUT_FORMAT_OGG) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Error setting format: %s", shout_get_error(shout));
  return 1;
 }

 shout_set_public(shout, s_public);

 if (s_desc  != NULL)
  shout_set_description(shout, s_desc);

 if (s_genre != NULL)
  shout_set_genre(shout, s_genre);

 if (s_name  != NULL)
  shout_set_name(shout, s_name);

 if (s_url   != NULL)
  shout_set_url(shout, s_url);

 if ( (vss = roar_vs_new_simple(server, "roarshout",
                                info.rate, info.channels, info.codec, info.bits,
                                ROAR_DIR_MONITOR, &err)) == NULL ) {
  fprintf(stderr, "Error: can not start monitoring: %s\n", roar_vs_strerr(err));
  return 1;
 }

 if (shout_open(shout) != SHOUTERR_SUCCESS) {
  ROAR_ERR("Can not open connection via libshout!");
  return -1;
 }

 while((ret = roar_vs_read(vss, buf, BUFSIZE, NULL)))
  if (shout_send(shout, (unsigned char*)buf, i) != SHOUTERR_SUCCESS)
   break;

 roar_vs_close(vss, ROAR_VS_TRUE, NULL);

 shout_sync(shout);

 shout_close(shout);

 shout_shutdown();

 return 0;
}

#else
int main (void) {
 fprintf(stderr, "No libshout support compiled in!\n");
 return 1;
}
#endif
//ll

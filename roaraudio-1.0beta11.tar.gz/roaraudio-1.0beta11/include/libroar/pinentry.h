//pinentry.h:

/*
 *      Copyright (C) Philipp 'ph3-der-loewe' Schafft - 2009-2014
 *
 *  This file is part of libroar a part of RoarAudio,
 *  a cross-platform sound system for both, home and professional use.
 *  See README for details.
 *
 *  This file is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3
 *  as published by the Free Software Foundation.
 *
 *  libroar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; see the file COPYING.  If not, write to
 *  the Free Software Foundation, 51 Franklin Street, Fifth Floor,
 *  Boston, MA 02110-1301, USA.
 *
 *  NOTE for everyone want's to change something and send patches:
 *  read README and HACKING! There a addition information on
 *  the license of this document you need to read before you send
 *  any patches.
 *
 *  NOTE for uses of non-GPL (LGPL,...) software using libesd, libartsc
 *  or libpulse*:
 *  The libs libroaresd, libroararts and libroarpulse link this lib
 *  and are therefore GPL. Because of this it may be illigal to use
 *  them with any software that uses libesd, libartsc or libpulse*.
 */

#ifndef _LIBROAR_PINENTRY_H_
#define _LIBROAR_PINENTRY_H_

#include "libroar.h"

//pinentry.h

struct roar_pinentry {
 int opened;
 pid_t pid;
 int in;
 int out;
 FILE * fin;
};

int roar_pinentry_open (struct roar_pinentry * pe, int flags, const char * display, const char * tty, const char * term);
int roar_pinentry_simple_open(struct roar_pinentry * pe);
int roar_pinentry_close(struct roar_pinentry * pe);

int roar_pinentry_send (struct roar_pinentry * pe, char *  cmd,  char *  args);
int roar_pinentry_recv (struct roar_pinentry * pe, char ** line, char ** opts);
int roar_pinentry_req  (struct roar_pinentry * pe, char *  cmd,  char *  args, char ** line, char ** opts);

int roar_pinentry_set_desc (struct roar_pinentry * pe, char * desc);
int roar_pinentry_set_prompt(struct roar_pinentry * pe, char * prompt);
int roar_pinentry_set_yes  (struct roar_pinentry * pe, char * yes);
int roar_pinentry_set_no   (struct roar_pinentry * pe, char * no);
int roar_pinentry_set      (struct roar_pinentry * pe, char * obj, char * text);

int roar_pinentry_getpin   (struct roar_pinentry * pe, char ** pw, char * desc, char * prompt);
int roar_pinentry_confirm  (struct roar_pinentry * pe, char *  desc, char * yes, char * no);

#endif

//ll

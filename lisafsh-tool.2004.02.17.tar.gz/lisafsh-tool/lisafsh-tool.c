/**************************************************************************************\
*                   A part of the Apple Lisa 2 Emulator Project                        *
*                        Internal Project Name:    reenignE                            *
*                               (engineer reversed)                                    *
*                            Pronounced Ree-neegh-nee                                  *
*                                                                                      *
*                    Copyright (C) MMIV Ray A. Arachelian                              *
*                            All Rights Reserved                                       *
*                                                                                      *
*                     Release Project Name: LisaFSh Tool                               *
*                                                                                      *
\**************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
// change these to match your platform/os/compiler.  Alternatively you can steal/include a
// types.h file.  :)

typedef unsigned long uint32;
typedef unsigned int  uint16;
typedef unsigned char uint8;

const uint16 dispsize=16;

int tagsaresorted=0;
uint32 sector=0;
uint32 clustersize=512;
uint32 havetags=0L;


typedef struct
{
  int sector;     // which sector is this?
  char *tagptr;
} sorttag_type;
//  char unkno1[4]; //00-03
//  char fileid[2]; //04-05
//  char absrel[2]; //06-07
//  char fwdrel[2]; //09-0b
//  char bkdrel[2]; //0a-0b

//  (Almost) the same structure I use in the emulator - this way code can be reused somewhat.
typedef struct
{
    FILE *fhandle;
    char *filename;
    uint8  ftype;                         // floppy type 0=twig, 1=sony400k, 2=sony800k, 3=freeform, 254/255=disabled
    uint32 sectoroffset;                  // how far to 1st sector
    uint16 sectorsize; //=512;
    uint32 tagstart;                      // how far to 1st tag
    uint32 tagsize; //=12;
    uint32 maxtrk, maxsec,maxside, numblocks;

    char *sectors;
    char *tags;
    char *allocated;
    uint8 ramdisk_enable;

    int *sorttag;
} FloppyType;

FloppyType F;

char volumename[32];
uint16 fsversion=0;
uint32 firstmddf=65536;

char filenames[65536][2][64];         // [fileid][size of file name][2] 0=Lisa name 1=sanitized name
                                      // cached file names for all the tags - kind of big, I know.

char directory[65536];
// the first few sectors of a disk are reserved for the boot sector + os loader
#define RESERVED_BLOCKS 28

#define TAG_BOOTSECTOR 0xaaaa
#define TAG_OS_LOADER  0xbbbb
#define TAG_FREE_BLOCK 0x0000
#define TAG_ERASED_BLK 0x7fff

#define TAG_MDDF       0x0001
#define TAG_FREEBITMAP 0x0002
#define TAG_S_RECORDS  0x0003
#define TAG_DIRECTORY  0x0004
#define TAG_MAXTAG     0x7fff


// command line user interface verbs  ////////////////////////////////////////////////////////////////
long iargs[10];
char cargs[10][256];


enum command_enum {sectorset=0,    cluster=1, display=2, setclustersize=3, dump=4, tagdump=5,
                   sorttagdump=6, sortdump=7, extract=8,  version=9, help=10, quit=11, bitmap=12,
                   sortnext=13,sortprevious=14,dir=15};
enum command_enum command;
#define QUITCOMMAND 11
#define LASTCOMMAND 16
char *cmdstrings[LASTCOMMAND+1] =
                  {"sector",       "cluster","display", "setclustersize", "dump","tagdump",
                   "sorttagdump",  "sortdump","extract", "version", "help",  "quit", "bitmap",
                   "n",         "p",            "dir",""};

#define NULL_CMD         -999
#define SECTOR_PRV         -2
#define SECTOR_NXT         -1
#define SECTOR_CMD          0
#define CLUSTER_CMD         1
#define DISPLAY_CMD         2
#define SETCLUSTERSIZE_CMD  3
#define DUMP_CMD            4
#define TAGDUMP_CMD         5
#define SORTTAGDUMP_CMD     6
#define SORTDUMP_CMD        7
#define EXTRACT_CMD         8
#define VERSION_CMD         9
#define HELP_CMD           10
#define QUIT_CMD           11
#define BITMAP_CMD         12
#define SORT_NEXT          13
#define SORT_PREV          14
#define DIR_CMD            15



// Prototypes and Macros //////////////////////////////////////////////////////////////////////
void sorttags(FloppyType *F);
void dump_mddf(FILE *out, FloppyType *F);
void get_allocation_bitmap(FloppyType *F);
void filenamecleanup(char *in, char *out);
void get_dir_file_names(FloppyType *F);
char *getfileid(int sector);
char *getfileidbyid(uint16 fileid);
static int tagcmp(const void *p1, const void *p2);
void extract_files(FloppyType *F);
void getcommand(void);
int floppy_disk_copy_image_open(FloppyType *F);
void hexprint(FILE *out, char *x, int size, int ascii_print);
void printsectheader(FILE *out, FloppyType *F, uint32 sector);
void printtag(FILE *out,FloppyType *F, uint32 sector);
void printsector(FILE *out,FloppyType *F, uint32 sector,uint32 sectorsize);
void cli(FloppyType *F);


// careful, cannot use ++/-- as parameters for TAGFILEID macro.
#define TAGFILEID(mysect)  (((F->tags[(F->tagsize *(mysect))+4] & 0xff)<<8)|((F->tags[(F->tagsize *(mysect))+5]) & 0xff))
#define TAGFFILEID(mysect) (((F.tags[(F.tagsize *(mysect))+4] & 0xff)<<8)|((F.tags[(F.tagsize *(mysect))+5]) & 0xff))


////////////////////////////////////////////////////////////////////////////////////////////////

static int tagcmp(const void *p1, const void *p2)
{

uint16 fileid1, fileid2,  abs1, abs2, next1, next2, prev1, prev2;

	 // turn voids into sort tag types
     int i = ( *(int *)p2 ) * F.tagsize;
     int j = ( *(int *)p1 ) * F.tagsize;

     fileid1=((F.tags[i+0x04]<<8)|F.tags[i+0x05])        ;
     fileid2=((F.tags[j+0x04]<<8)|F.tags[j+0x05])        ;

     abs1   =((F.tags[i+0x06]<<8)|F.tags[i+0x07]) & 0x7ff;
     abs2   =((F.tags[j+0x06]<<8)|F.tags[j+0x07]) & 0x7ff;

     next1  =((F.tags[i+0x08]<<8)|F.tags[i+0x09]) & 0x7ff;
     next2  =((F.tags[j+0x08]<<8)|F.tags[j+0x09]) & 0x7ff;

     prev1  =((F.tags[i+0x0a]<<8)|F.tags[i+0x0b]) & 0x7ff;
     prev2  =((F.tags[j+0x0a]<<8)|F.tags[j+0x0b]) & 0x7ff;


     // sort keys in order: file id, absolute sector #, next sector #

     if (fileid1>fileid2) return -1;
     if (fileid1<fileid2) return +1;

     if (abs1>abs2)       return -1;
     if (abs1<abs2)       return +1;

     if (next1>next2)     return -1;
     if (next1<next2)     return +1;

                          return  0; // if we made it here, they're equal, uh? problem possibly.
}


// Sort the tags by the keys above, then extract information that's tag sensitive.
void sorttags(FloppyType *F)
{
 int i;
 for (i=0; i<F->numblocks; i++) F->sorttag[i]=i; // copy the tags to the unsorted pointers
 qsort((void *)F->sorttag, (size_t) F->numblocks, sizeof (int), tagcmp); // sort the pointers

 get_allocation_bitmap(F);
 get_dir_file_names(F);
 dump_mddf(stdout,F);
}

// Dump the data in the MDDF - Thanks to Chris McFall for this info.  :)
void dump_mddf(FILE *out, FloppyType *F)
{
 char *sec;
 int i,j ;
 uint32 sector, sect;

 if (!volumename[0])                        // if we already did the work don't bother.
  {//fprintf(out,"Searching for MDDF block.\n");
   for (sector=0; sector<F->numblocks; sector++)
     {
       sect=F->sorttag[sector];
       sec=&(F->sectors[sect*F->sectorsize]);
       if (TAGFILEID(sect)==TAG_MDDF)
       {
        for (j=0,i=0x0d; i<0x20; i++,j++) volumename[j]=sec[i];

        fsversion=(sec[0]<<8)|sec[1];

        if (sect<firstmddf) firstmddf=sect;  // keep track of the first one in the image for bitmap sizing.

        fprintf(out,"MDDF (Superblock) found at sector #%04x(%4d) fsversion:%02x\n",sect,sect,fsversion);
       }
     }
     if (!fsversion) fprintf(out,"MDDF not found.\n");
  }
 fprintf(out,"\n-----------------------------------------------------------------------------\n");
 fprintf(out,"MDDF Volume Name: \"%s\"\n",volumename);
 switch(fsversion)
 {
  case 0x00 : fprintf(out,"FS Version information not found or MDDF version=0 or bad MMDF!\n"); break;
  case 0x0e : fprintf(out,"Version 0x0e: Flat File System with simple table catalog Release 1.0\n"); break;
  case 0x0f : fprintf(out,"Version 0x0f: Flat File System with hash table catalog Release 2.0 - Pepsi\n"); break;
  case 0x11 : fprintf(out,"Version 0x11: Hierarchial FS with B-Tree catalog Spring Release - 7/7\n"); break;

  default   : fprintf(out,"Unknow MDDF Version: %02x Could be we didn't find the right MDDF\n",version);
 }
 fprintf(out,"-----------------------------------------------------------------------------\n");
}

void get_allocation_bitmap(FloppyType *F)
{
 uint32 sector, i, as=RESERVED_BLOCKS    ;   // sector is the search for the allocation bitmap, as is the active sector
 uint16 fileid, tagfileid;
 char *sec;


 // reserve all sectors initially as used. the code below will free them
 for (i=0; i<F->numblocks; i++) F->allocated[i]=9;

 // find and process all allocation bitmap block(s)
 //printf("Searching for block allocation bitmap blocks...\n");
 for (sector=0; sector<F->numblocks; sector++)
 {
   if (TAGFILEID(sector)==TAG_FREEBITMAP)                  // is this a bitmap block?
   {
     printf("Found allocation bitmap block at sector #%04x(%d)\n",sector,sector);
     sec=&(F->sectors[sector*F->sectorsize]);     // do all the bits in this block until we go over the # of max sectors.
     for (i=0; i<F->sectorsize; i++)              // ??? might need to change this to match offsets ????
     {
      // This checks two things: one is the bitmap allocation bit corresponding to the active sector, and sets
      // it to 8 if it's on.  Then it checks the file id, if the file id=0, it'll set it to 1.  So if the
      // theory that the file id=0000 when the block is free holds true, the whole of F->allocated should
      // consists of only 0's and 9's.

      if (as>F->numblocks) break;       // the allocation bitmap is much larger than can fit inside a single sector.
                                        // so we have to ignore the rest of the bits therein.
                                        // (since 1 sector=512 bytes, 512*(8 bits/byte)=4096 allocated bits are available
                                        // but only 800 sectors in a 400k floppy, 1600 in an 800k, 2888 in a 1.4MB.
                                        // So we need to bail out before we overrun the F->allocated array.

      // Figure out which sectors are allocated or free.  We do this by both
      // checking the allocation bitmap block, *AND* the tags so that we can
      // detect errors in our code/assumptions.  For example, because of this,
      // I've discovered the posibility that 0x7fff is the tag file ID for
      // an erased block.

      // Macros to make the below block simpler for humans to read. :)
      #define USEDTAG (tagfileid!=TAG_ERASED_BLK && tagfileid!=TAG_FREE_BLOCK)
      #define ALLOC F->allocated[as]

      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &   1) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &   2) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &   4) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &   8) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &  16) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &  32) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] &  64) ? 8:0) | USEDTAG); as++;
      tagfileid=TAGFILEID(as); ALLOC=(((sec[i] & 128) ? 8:0) | USEDTAG); as++;

      #undef USEDTAG
      #undef ALLOC
     }//for sector size
   }
 }
}

void dump_allocation_bitmap(FILE *out, FloppyType *F)
{
 int i,j;
 char c;
 fprintf(out,"\n                  Block allocation bitmap\n");
 fprintf(out,"----------+----------------------------------------+\n");
 fprintf(out,"Sector    |..........1.........2........3..........|\n");
 fprintf(out,"hex dec  +|0123456789012345678901234567890123456789|\n");
 fprintf(out,"----------+----------------------------------------|\n");

 for (j=0; j<F->numblocks; j+=40)
 {
  fprintf(out,"%04x(%04d)|",j,j);
  for (i=0; i<40; i++)
       {
        switch(F->allocated[i+j])
        {
          case 0:  c=' '; break;
          case 9:  c='#'; break;
          case 1:  c='.'; break;
          case 8:  c='8'; break;
          default: c='?'; break;
        }
        fprintf(out,"%c", c);
       }
  fprintf(out,"|\n");
 }
 fprintf(out,"----------+----------------------------------------+\n\n");
}

void filenamecleanup(char *in, char *out)
{
 uint32 i,j,l;
 char *f;
 char c;
      for (j=0; in[j] && j<63; j++)     // santize file name for most host OS's.
      {                                 // some of these are over cautious, i.e. spaces can be escaped in unix, etc...
                                        // but I want to make sure we don't cause needless trouble and require escaping
                                        // with lots of backslashes, etc.  In fact, you can even build file names containing
                                        // wildcards and slashes in unix, but accessing them from the commandline becomes
                                        // an excercise in backslash insanity
        c=in[j];
        switch(c)
          {
           case '"' :               // get rid of quotes
           case '`' :
           case '\'':
           case '?' :               // wild cards
           case '*' :
           case '/' : // slashes
           case '\\': c='-'; break;
           case ':' : c='-'; break; // colons for MSFT OS's

           case '!' :               // !'s for unix
           case '&' :               // this means background in most unix shells.
           case '$' :               // shell environment variables for unix + windows
           case '%' :

           case '<' :               // redirects and pipe
           case '>' :
           case '|' :
           case '(' :
           case ')' :
           case '[' :
           case ']' :
                      c='_';
          }
        if (c<33 || c>126) c='_';     // control and high chars

        out[j]=c;
      }
      out[63]=0; // make double dog sure the string is terminated;
}

// Walk the directory catalog and read all of the file names stored in there
// then store them in the table.
void get_dir_file_names(FloppyType *F)
{
 uint32 sector, mysect, i,j,k,ti,ts, as=0;       // sector is the search for the allocation bitmap, as is the active sector
 uint16 fileid;
 char *sec, *f;

 int offset=0x10;                               // start offset

 char filename[128];                            // current file name I'm working on

 for (i=0; i<65536; i++)                        // set default file names
  {
   f=getfileidbyid(i);
   strncpy(filenames[i][0],f,63);
   filenamecleanup(filenames[i][0],filenames[i][1]);
  }

 // Walk all (sorted) sectors until we find the directory entries.
 i=0x10;                                                       // initial filename position for 1st dir block
 for (sector=0; sector<F->numblocks; sector++)
 {
   mysect=F->sorttag[sector];

   if (TAGFILEID(mysect)==TAG_DIRECTORY)     // is this a directory block? /////////////////////////////////////////
   {                                         // Yes? Walk it for filenames and extract tag id's.
     //printf("Searching directory at sector %d\n",mysect);
     sec=&(F->sectors[mysect*F->sectorsize]);
     while(i+=64)       // every 64 bytes is a directory entry.
     {
       if (i>511)                                              // check to see if we went over sector boundary
       {  sector++; i-=512;                                    // advance to the next sector, fix index.
          mysect=F->sorttag[sector];                           // get the sorted sector
          sec= &(F->sectors[mysect*F->sectorsize]);            // get next data pointer
          if (TAGFILEID(mysect)!=TAG_DIRECTORY) return;        // done, we've gone out of the last dir.
          //printf("Searching directory at sector %d\n",mysect);
       }

       if (sec[i]==0 && sec[i+1]>31)                           // do we have a null in [0] and text byte in [1]?
       {                                                       // file name starts on the 1st byte, not the zeroth byte.
         for (j=0,k=i+1;j<32; j++,k++) filename[j]=sec[k];     // copy the file name
         filename[31]=0;                                       // make sure it's terminated
         // get the file ID for this sector.
         fileid=(sec[i+32+4]<<8)|sec[i+32+5];                  // get the tag for this file



         // If the file id tag isn't a reserved fileid type *AND*
         // it exists in the sectors, then we likely have a real
         // file name, so save it.

         if (fileid!=TAG_BOOTSECTOR && fileid!=TAG_OS_LOADER && fileid!=TAG_FREE_BLOCK &&
             fileid!=TAG_ERASED_BLK && fileid!=TAG_MDDF      && fileid!=TAG_FREEBITMAP &&
             fileid!=TAG_S_RECORDS  && fileid!=TAG_DIRECTORY                              )
            for (ti=0; ti<F->numblocks; ti++)
            {
             ts=F->sorttag[ti];
             if (TAGFILEID(ts)==fileid)
              {// associate the file name with the tag file id.
               char temp[1024];

               strncpy(filenames[fileid][0],filename,63);      // add Lisa File name to generic file id name
               filenamecleanup(filenames[fileid][0],           // clean it up, now output name is set
                               filenames[fileid][1]);
               //strncpy(filenames[fileid][0],filename,31);    // copy lisa name over generic name
               //printf("Found file name:%s for file tag id:%04x in sector %04x(%d) at offset:%04x(%d)\n",filename,fileid,mysect,mysect,i,i);
               snprintf(temp,1023,"%04x     %-32s    %04x(%d)\n",fileid,filename,ts,ts);
               strncat(directory,temp,65535);                  // add filename to directory.
               break;                                          // quit searching
              }
            }

       } // else {printf("No filename at offset %04x(%d) in sector %04x(%d)\n",i,i,mysect,mysect);}


     }///for sector size /////////////////////////////////////////////////////////////////////////////////////////
   }
   else if ( TAGFILEID(mysect)>TAG_DIRECTORY) break;  // don't bother looking for more dirs, these are sorted.
 } // for sector loop ///////////////////////////////////////////////////////////////////////////////////////////


}


void extract_files(FloppyType *F)
{
  /*-----------------2/15/2004 6:57PM-----------------
   * extract all files inside of a disk image
   *
   * This could use better error handling, and also needs
   * to extract the friendly+system file names.  For now
   * like all things, it's a damned hack. ;)
   * --------------------------------------------------*/

  FILE *fh=NULL, *fb=NULL, *fx=NULL;    // file handles for header, binary, and hex
  int sector=0;                         // sector number
  char newfile[1024];                   // name of file or name of header metadata
  char newfilex[1024];                  // name of hex/text file to create
  char newfileb[1024];                  // name of binary file to create
  char newfilemb[1024];                 // name of meta data binary file to create
  char newfilemh[1024];                 // name of meta data hex binary file to create

  char newdir[1024];                    // name of new directory to create
  char *sub;                            // substring search to chop extension
  char *sec;                            // pointer to sector data

  char *tagtype=NULL;   int chop0xf0=0; // type of file ID, and whether there's a metadata attached.
  uint16 fileid, oldfileid=0xffff;
  char fileidhex[64];                   // file id in text form
  int sect;                             // translated sector number
  int err;
  // create a directory with the same name as the image in the current directory and enter it ////////
  snprintf(newfile,1023,F->filename);

  // whack off any extensions           // Butthead: "Huh huh, huh huh, he said 'Whack!'"
                                        // Beavis:   "Yeah, Yeah! Then he said 'Extensions'"
                                        // Butthead: "Huh huh, huh huh, that was cool!"

  sub=strstr(newfile,".dc42");  if (sub) *sub=0;
  sub=strstr(newfile,".DC42");  if (sub) *sub=0;
  sub=strstr(newfile,".dc");    if (sub) *sub=0;
  sub=strstr(newfile,".DC");    if (sub) *sub=0;
  sub=strstr(newfile,".image"); if (sub) *sub=0;
  sub=strstr(newfile,".Image"); if (sub) *sub=0;
  sub=strstr(newfile,".img");   if (sub) *sub=0;
  sub=strstr(newfile,".IMG");   if (sub) *sub=0;
  sub=strstr(newfile,".dmg");   if (sub) *sub=0;
  sub=strstr(newfile,".DMG");   if (sub) *sub=0;



  // add a .d to the file name, then create and enter the directory
  snprintf(newdir,1023,"%s.d",newfile);
  printf("Creating directory %s to store extracted files\n",newdir);

  err=mkdir(newdir,00755);

  // Might want to change this to ask if it's ok to overwrite this directory.
  if (err && errno!=EEXIST)  {fprintf(stderr,"Couldn't create directory %s because (%d)",newdir,err);
                              perror("\n"); return;}
  if (chdir(newdir))         {fprintf(stderr,"Couldn't enter directory %s because",newdir);
                              perror("\n"); return;}

  // Extract the entire disk //////////////////////////////////////////////////////////////////////////


  errno=0;


  // extract files -----------------------------------------------------------------------

  for (sector=0; sector<F->numblocks; sector++)
       {
        sect=F->sorttag[sector];        // dump files from sectors in sorted order
        fileid=TAGFILEID(sect);

        if (fileid!=oldfileid)          // we have a file id we haven't seen before. open new file handles
        {
          fflush(stdout); fflush(stderr);
          if (fx) {fflush(fx); fclose(fx); fx=NULL;}
          if (fb) {fflush(fb); fclose(fb); fb=NULL;}
          if (fx) {fflush(fh); fclose(fh); fh=NULL;}

          printf("%04x!=%04x",fileid,oldfileid);


          if (strlen(filenames[fileid][1])) snprintf(newfile,63,"%s",   filenames[fileid][1]);
          else                              snprintf(newfile,63,"%s",   getfileid(sect)                     );
          printf("Extracting: %s -> %s (.bin/.txt)\n",filenames[fileid][0],newfile);

          chop0xf0=1;                 // default for normal files is to have a header
                                      // but special files do not, so catch those
                                      // and don't chop the first 0xf0 bytes

          if (fileid==TAG_BOOTSECTOR) chop0xf0=0;  // boot sector
          if (fileid==TAG_OS_LOADER ) chop0xf0=0;  // os loader
          if (fileid==TAG_ERASED_BLK) chop0xf0=0;  // deleted blocks
          if (fileid==TAG_FREE_BLOCK) chop0xf0=0;  // free blocks
          if (fileid==TAG_MDDF      ) chop0xf0=0;  // mddf
          if (fileid==TAG_FREEBITMAP) chop0xf0=0;  // allocation bitmap
          if (fileid==TAG_S_RECORDS ) chop0xf0=0;  // s-records
          if (fileid==TAG_DIRECTORY ) chop0xf0=0;  // directory
          if (fileid >TAG_MAXTAG    ) chop0xf0=0;  // catch other unknown file id's

          snprintf(newfilex,1024,"%s.txt",newfile);
          fx=fopen(newfilex,"wt");
          if (!fx)                  {fprintf(stderr,"Couldn't create file %s\n",newfilex);
                                     perror("\n"); chdir(".."); return;}

          snprintf(newfileb,1024,"%s.bin",newfile);
          fb=fopen(newfileb,"wb");
          if (!fb)                  {fprintf(stderr,"Couldn't create file %s\n",newfileb);
                                     perror("\n"); chdir(".."); return;}

          //printf("File:%s starts at sector %d %s metadata\n",newfile, sect, chop0xf0 ? "has":"has no ");

          if (chop0xf0)                 // deal with meta data bearing files----------------------
          {
              // We need to chop off the 1st 0xf0 bytes as they're part of the metadata of the file.
              // create two metadata files, one binary, and one hex.
              snprintf(newfilemb,1024,"%s.meta.bin",newfile);
              fh=fopen(newfilemb,"wb");
              if (!fh)                  {fprintf(stderr,"Couldn't create file %s\n",newfilemb);
                                         perror("\n"); chdir(".."); return;}
              sec=&(F->sectors[sect*F->sectorsize]);
              fwrite(sec,0xf0,1,fh); fclose(fh); fh=NULL;
              if (errno) {fprintf(stderr,"An error occured on file %s",newfile); perror("");
                         fclose(fb); fclose(fx); chdir(".."); return;}

              //write remainder of sector to the binary file
              sec=&(F->sectors[sect*F->sectorsize+0xf0]);
              fwrite(sec,(F->sectorsize-0xf0),1,fb);
              if (errno) {fprintf(stderr,"An error occured on file %s",newfileb); perror("");
                         fclose(fb); fclose(fx); chdir(".."); return;}


              snprintf(newfilemh,1024,"%s.meta.txt",newfile);
              fh=fopen(newfilemh,"wb");
              if (!fh)                  {fprintf(stderr,"Couldn't create file %s\n",newfilemh);
                                         fclose(fb); fclose(fx); perror("\n"); chdir(".."); return;}
              printsector(fh,F,sect,0xf0); fclose(fh); fh=NULL;
              if (errno) {fprintf(stderr,"An error occured on file %s",newfileb); perror("");
                         fclose(fb); fclose(fx); chdir(".."); return;}

              // dump the data to the hex file, but add a banner warning about metadata.
              fprintf(fx,"\n\n[Metadata from bytes 0x0000-0x00ef]\n");
              printsector(fx,F,sect,F->sectorsize);

              oldfileid=fileid;             // set up for next round
              continue;                 // skip to the next sector, this one is done ----------------
          } // end of chop0xf0 ----------------------------------------------------------------------

        } // end of new file comparison on oldfileid/fileid  ----------------------------------------


        // now, write the sector out in hex and binary. ---------------------------------------------
        //printf("Writing sector %04x(%d) to %s\n",sect,sect,newfile);
        printsector(fx,F,0,F->sectorsize);

        if (errno) {fprintf(stderr,"An error occured on file %s.txt",newfile); perror("");
                   fclose(fb); fclose(fx); chdir(".."); return;}

        fwrite(sec,F->sectorsize,1,fb);
        if (errno) {fprintf(stderr,"An error occured on file %s.bin",newfile); perror("");
                   fclose(fb); fclose(fx); chdir(".."); return;}

        oldfileid=fileid;             // set up for next round

       } // end of all sectors. ---------------------------------------------------------------------

       // cleanup and return;
       if (fx) {fflush(fx); fclose(fx); fx=NULL;}
       if (fb) {fflush(fb); fclose(fb); fb=NULL;}
       if (fx) {fflush(fh); fclose(fh); fh=NULL;}
       chdir("..");
       return;
}


// return the type of file we are dealing with.
char *getfileid(int sector)
{
  uint32 fileid;
  static char fileidtext[64];            // needs to be static so it doesn't fall off the heap when this fn exits

  fileid=TAGFFILEID(sector);//((F.tags[(F.tagsize *(sector))+4] & 0xff)<<8)|((F.tags[(F.tagsize *(sector))+5]) & 0xff);

  snprintf(fileidtext,63,"file-%04x",fileid);

  if (fileid >TAG_MAXTAG    ) snprintf(fileidtext,63,"UnKnowN-%04x",fileid);
  if (fileid==TAG_ERASED_BLK) snprintf(fileidtext,63,"deleted-blocks-7fff");
  if (fileid==TAG_BOOTSECTOR) snprintf(fileidtext,63,"bootsect-aaaa");
  if (fileid==TAG_OS_LOADER ) snprintf(fileidtext,63,"OSLoader-bbbb");
  if (fileid==TAG_FREE_BLOCK) snprintf(fileidtext,63,"freeblocks-0000");
  if (fileid==TAG_MDDF      ) snprintf(fileidtext,63,"MDDF-0001");
  if (fileid==TAG_FREEBITMAP) snprintf(fileidtext,63,"alloc-bitmap-0002");
  if (fileid==TAG_S_RECORDS ) snprintf(fileidtext,63,"srecords-0003");
  if (fileid==TAG_DIRECTORY ) snprintf(fileidtext,63,"directory-0004");
  return fileidtext;
}

char *getfileidbyid(uint16 fileid)
{
  static char fileidtext[64];            // needs to be static so it doesn't fall off the heap when this fn exits
  snprintf(fileidtext,63,"file-%04x",fileid);

  if (fileid >TAG_MAXTAG    ) snprintf(fileidtext,63,"unknown-%04x",fileid);  // catch other unknown file id's
  if (fileid==TAG_BOOTSECTOR) snprintf(fileidtext,63,"bootsect-aaaa");
  if (fileid==TAG_OS_LOADER ) snprintf(fileidtext,63,"OSLoader-bbbb");
  if (fileid==TAG_FREE_BLOCK) snprintf(fileidtext,63,"freeblocks-0000");
  if (fileid==TAG_MDDF      ) snprintf(fileidtext,63,"MDDF-0001");
  if (fileid==TAG_FREEBITMAP) snprintf(fileidtext,63,"alloc-bitmap-0002");
  if (fileid==TAG_S_RECORDS ) snprintf(fileidtext,63,"srecords-0003");
  if (fileid==TAG_DIRECTORY ) snprintf(fileidtext,63,"directory-0004");
  return fileidtext;
}



void getcommand(void)
{
char line[2048];
char *space, *s;
int i;
long len,l;

bzero(cargs,10*256);

command=LASTCOMMAND;
fgets(line,2040,stdin);
len=strlen(line);
if (feof(stdin)) {puts(""); exit(1);}
if (len) line[--len]=0; else return; // knock out eol char
if (!len) {command=-1;return;}       // shortcut for next sector.
if (line[0]=='!')                 {if (len==1) system("sh");
                                   else        system(&line[1]);
                                   command=NULL_CMD;}                                       // shell out
if (line[0]=='?')                 {strncpy(line,"help",6);}                                 // help synonym
if (line[0]=='+' && len==1)       {command=SECTOR_NXT; return;}                             // next sector
if (line[0]=='-' && len==1)       {command=SECTOR_PRV; return;}                             // previous sector
if (line[0]=='+' || line[0]=='-') {l=strtol(line,NULL,0);sector+=l; command=DISPLAY_CMD; return;} // delta jump

space=strchr(line,32);
if (space) space[0]=0;

for (i=0; i<LASTCOMMAND; i++) if (strncmp(line,cmdstrings[i],16)==0) command=i;
// shortcut for sector number
iargs[0]=strtol(line,NULL,0); if ( line[0]>='0' && line[0]<='9' ) {command=0; return;}
if (command==LASTCOMMAND) {puts("Say what?  Type in help for help..\n"); return;}
if (command==QUITCOMMAND) exit(1);
if (!space) return;
line[len]=' ';
line[len+1]=0;

s=space+1;
i=0;
while (  (space=strchr(s,(int)' '))!=NULL && i<10)
 {
  *space=0; strncpy(cargs[i],s,255);
  iargs[i]=strtol(s, NULL, 0);
  s=space+1; i++;
 }


}

int floppy_disk_copy_image_open(FloppyType *F)
{

uint32 i,j;
char comment[64];
char dc42head[8192];
uint32 datasize, tagsize, datachks, tagchks, mydatachks=0L, mytagchks=0L;
uint16 diskformat, formatbyte, privflag;

	errno=0;
	fseek(F->fhandle, 0,0);
	fread(dc42head,84,1,F->fhandle);
	if (errno) {perror("Got an error."); exit(1);}

	memcpy(comment,&dc42head[1],64);
	comment[63]=0;
	if (dc42head[0]>63) {fprintf(stderr,"Warning pascal str length of label is %d bytes!\n",(int) (dc42head[0]));}
	else comment[dc42head[0]]=0;

	F->sectoroffset=84;
	datasize=(dc42head[64+0]<<24)|(dc42head[64+1]<<16)|(dc42head[64+2]<<8)|dc42head[64+3];
	tagsize =(dc42head[68+0]<<24)|(dc42head[68+1]<<16)|(dc42head[68+2]<<8)|dc42head[68+3];
	datachks=(dc42head[72+0]<<24)|(dc42head[72+1]<<16)|(dc42head[72+2]<<8)|dc42head[72+3];
	tagchks =(dc42head[76+0]<<24)|(dc42head[76+1]<<16)|(dc42head[76+2]<<8)|dc42head[76+3];

	F->tagstart=84+datasize;

	diskformat=dc42head[80];
	formatbyte=dc42head[81];
    privflag=(dc42head[82]<<8 | dc42head[83]);

	printf("Header comment :\"%s\"\n",comment);
	printf("Data Size      :%ld (0x%08x)\n",datasize,datasize);
	printf("Tag total      :%ld (0x%08x)\n",tagsize,tagsize);
	printf("Data checksum  :%ld (0x%08x)\n",datachks,datachks);
	printf("Tag checksum   :%ld (0x%08x)\n",tagchks,tagchks);
	printf("Disk format    :%d  ",diskformat);

	switch(diskformat)
	{
		case 0: printf("400K GCR\n"); break;
		case 1: printf("800K GCR\n"); break;
		case 2: printf("720K MFM\n"); break;
		case 3: printf("1440K MFM\n"); break;
		default: printf("unknown\n");
	}
	printf("Format byte    :0x%02x   ",formatbyte);
	switch(formatbyte)
	{
		case 0x12: printf("400K\n"); break;
		case 0x22: printf(">400k\n"); break;
		case 0x24: printf("800k Apple II Disk\n"); break;
		default: printf("unknown\n");
	}
    printf("Private        :0x%04x (should be 0x100)\n",privflag);
	printf("Data starts at :0x%04x (%ld)\n",84,84);
	printf("Tags start at  :0x%04x (%ld)\n",F->tagstart,F->tagstart);
	F->sectorsize=512;
    F->numblocks=datasize/F->sectorsize;
	F->tagstart=84 + datasize;
	F->tagsize=tagsize/F->numblocks;

    F->numblocks=datasize/F->sectorsize;        // turn this back into 512 bytes.

	if (F->numblocks==800)
	{
		F->maxtrk=80; F->maxsec=13;F->maxside=0;
		F->ftype=1;
	}
	if (F->numblocks==1600)
	{
		F->maxtrk=80; F->maxsec=13 ;F->maxside=1;
		F->ftype=2;
	}
	printf("No of sectors  :0x%04x (%d)\n",F->numblocks,F->numblocks);
	printf("Sector size    :0x%04x (%d)\n",F->sectorsize,F->sectorsize);
	printf("tag size       :0x%04x (%d)\n",F->tagsize,F->tagsize);

	F->tagsize=12; // force it for now.

    //printf("Allocating %d bytes (%d blocks * %d sectorsize)",4+F->numblocks*F->sectorsize,F->numblocks,F->sectorsize);
	(void*)F->sectors=malloc(4+ F->numblocks * F->sectorsize) ; if ( !F->sectors) {printf("- failed!\n"); return 1;}
	puts("");



    //printf("Allocating %d tag bytes (%d blocks * %d tagsize)",4+F->numblocks*F->tagsize,F->numblocks,F->tagsize);
    (void*)F->tags=        malloc(4+ F->numblocks * F->tagsize);     if ( !F->tags ) {printf(" - failed!\n"); return 1;}

    //printf("Allocating %d bytes for free bitmap (%d blocks)",4+F->numblocks*F->tagsize,F->numblocks);
    (void*)F->allocated=   malloc(4+ F->numblocks             );     if ( !F->allocated) {printf(" - failed!\n"); return 1;}

    //puts("");
    //puts("Cleaning allocated memory to 0xff");
    memset(F->sectors,  255,( F->numblocks * F->sectorsize) );
    memset(F->tags,     255,( F->numblocks * F->tagsize   ) );
    memset(F->allocated,255,( F->numblocks                ) );

	fflush(stdout);
	fflush(stdout);

        // do it in one shot
	fseek(F->fhandle,84,0);
	//fread((char *) F->sectors,F->sectorsize*F->numblocks,1,F->fhandle);
	fread((char *) F->sectors,F->sectorsize,F->numblocks,F->fhandle);
	if (errno) {perror("Got an error."); exit(1);}

	mydatachks=0;
	for (i=0; i<F->numblocks; i++)
     for (j=0; j<F->sectorsize; j++) mydatachks+=F->sectors[i*(F->sectorsize)+j];


	//fseek(F->fhandle, i *(F->tagsize)+(F->tagstart),0);
	//fread((char *) F->tags,F->tagsize*F->numblocks,1,F->fhandle);
	fread((char *) F->tags,F->tagsize,F->numblocks,F->fhandle);
	if (errno) {perror("Got an error."); exit(1);}

	mytagchks=0;
	for ( i=0; i<F->numblocks; i++)
            for (j=0; j<F->sectorsize; j++) {mytagchks+=F->sectors[i*(F->tagsize)+j]; havetags|=F->sectors[i*(F->tagsize)+j];}

	printf("Header/Calc data chksum   :%ld (0x%08x) ? %ld (0x%08x):\n",datachks,datachks,mydatachks,mydatachks);
	printf("Header/Calc tag chksum    :%ld (0x%08x) ? %ld (0x%08x):\n",tagchks,tagchks,mytagchks,mytagchks);
	puts("");

    if (!havetags)
            {
                puts("\n***** Looks like all tag data is null. You will not be able to do much with");
                puts("this Disk Image!  See the documentation for more information.");
            }


	errno=0;
	F->sorttag=(int *) malloc(F->numblocks * sizeof(int) +2);
	if (!F->sorttag) {perror("Couldn't allocate space for sortted tag index array\n"); exit(2);}

    return 0;
}

void hexprint(FILE *out, char *x, int size, int ascii_print)
{
int i,half;
unsigned char c;
char ascii[130];
half=(size/2) -1;
   if (size>128) {fprintf(stderr,"hexprintf given illegal size %d\n",size); exit(1);};
   memset(ascii,0,130);
   for (i=0; i<size; i++)
	{
	 c=x[i];

     if (i==half) fprintf(out,"%02x . ",c);
     else fprintf(out,"%02x ",c);

	 if (ascii_print)
          {
	    if (c>126) c &=127;
	    if (c<31)     c |= 32;
	    ascii[i]=c;
	  }
	}
   if (size<16) while(16-size) {fprintf(out,"   "); size++;}
   if (ascii_print) fprintf(out,"  |  %s\n",ascii);
}

void printsectheader(FILE *out,FloppyType *F, uint32 sector)
{
 uint32 fileid;
 fprintf(out,"\n-----------------------------------------------------------------------------\n");
 //fprintf(out,"Sec %d:(0x%04x) Cluster:%d, csize:%d ",sector,sector,sector/clustersize,clustersize);
 fprintf(out,"Sec %d:(0x%04x)  ",sector,sector);

 if (havetags)
 {    if (tagsaresorted)                     // when tags are sorted, allocation bitmap is extracted.
      fprintf(out," %s Block ",
      ((F->allocated[sector] & 8) ? "Used":"Free"));
      fileid=TAGFILEID(sector);
      fprintf(out,"Part of file %s:\"%s\"",getfileid(sector),filenames[fileid][0]);
 }

 fprintf(out,"\n-----------------------------------------------------------------------------\n");
 fprintf(out,"            +0 +1 +2 +3 +4 +5 . +6 +7 +8 +9 +a +b\n");
 fprintf(out,"tags:       ");
 hexprint(out,&F->tags[sector*F->tagsize],F->tagsize,0);
 fprintf(out,"\n           |volid| ??  |fileid|absnext|next|previous\n");
 fprintf(out,"-----------------------------------------------------------------------------\n");
 fprintf(out,"      +0 +1 +2 +3 +4 +5 +6 +7 . +8 +9 +a +b +c +d +e +f                    \n");
 fprintf(out,"-----------------------------------------------------------------------------\n");
}


void printtag(FILE *out,FloppyType *F, uint32 sector)
{
 char *s;

 switch (F->allocated[sector])
 {
     case 0:  s="free"; break;
     case 9:  s="used"; break;
     case 1:  s="ufid"; break;
     case 8:  s="ubit"; break;
     default: s="????"; break;
 }


 fprintf(out,"%4d(%04x): ", sector,sector);
 hexprint(out,&F->tags[sector*F->tagsize],F->tagsize,0);
 fprintf(out," %s\n",s);
}


void printsector(FILE *out,FloppyType *F, uint32 sector,uint32 sectorsize)
{

 uint16 i,j;
 char *sec;

 if (sector>F->numblocks) {fprintf(out,"not that many sectors!\n"); sector=F->numblocks-1;}

 printsectheader(out,F,sector);
 sec=&(F->sectors[sector*F->sectorsize]);
 for (i=0; i<sectorsize; i+=dispsize)
     { fprintf(out,"%04x: ",i); hexprint(out,(char *)(&sec[i]),dispsize,1); }
 fprintf(out,"\n");
}


void version_banner(void)
{
  //   ..........1.........2.........3.........4.........5.........6.........7.........8
  //   012345678901234567890123456789012345678901234567890123456789012345678901234567890
  puts("  ---------------------------------------------------------------------------");
  puts("    Lisa File System Shell Tool  v0.1      http://lisaem.sunder.net/lisafsh  ");
  puts("  ---------------------------------------------------------------------------");
  puts("        Copyright (C) MMIV, Ray A. Arachelian,   All Rights Reserved.");
  puts("              Released under the GNU Public License, Version 2.0");
  puts("    There is absolutely no warranty for this program. Use at your own risk.  ");
  puts("  ---------------------------------------------------------------------------\n");
}

void cli(FloppyType *F)
{
int i;
uint16 newsector;

while (1)
 {
   fflush(stderr); fflush(stdout);
   printf("lisafsh> ");
   getcommand();

   switch(command)
   {
       case  NULL_CMD :              break;
       case  SECTOR_NXT:             sector++; printsector(stdout,F,sector,F->sectorsize);break;
       case  SECTOR_PRV:             sector--; printsector(stdout,F,sector,F->sectorsize);break;
       case  SECTOR_CMD:             sector=iargs[0]; printsector(stdout,F,sector,F->sectorsize);break;
       case  CLUSTER_CMD:            sector=iargs[0]*clustersize/512; printsector(stdout,F,sector,F->sectorsize);break;
       case  DISPLAY_CMD:            printsector(stdout,F,sector,F->sectorsize); break;
       case  SETCLUSTERSIZE_CMD:     clustersize=iargs[0]; break;
       case  DUMP_CMD:               {for (sector=0; sector<F->numblocks; sector++) printsector(stdout,F,sector,F->sectorsize); } break;
       case  TAGDUMP_CMD:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           {
            puts("\n\n      +0 +1 +2 +3 +4 +5   +6 +7 +8 +9 +a +b");
 		    puts(  "-----------------------------------------------------------------------------");
            for (sector=0; sector<F->numblocks; sector++) printtag(stdout,F,sector);
           }
           break;
       case SORTTAGDUMP_CMD:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);   tagsaresorted=1;}
           puts("\n\n      +0 +1 +2 +3 +4 +5   +6 +7 +8 +9 +a +b");
           puts(    "-----------------------------------------------------------------------------");
           for (sector=0; sector<F->numblocks; sector++) printtag(stdout,F,F->sorttag[sector]);
		   break;
       case SORTDUMP_CMD:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
           for (sector=0; sector<F->numblocks; sector++) printsector(stdout,F,F->sorttag[sector],F->sectorsize);
		   break;
       case EXTRACT_CMD:
           // extract all Lisa files in disk based on the tags.
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
           extract_files(F);
           break;

       case BITMAP_CMD:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
           dump_allocation_bitmap(stdout,F); break;

       case SORT_NEXT:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
           { for (i=0; i<F->numblocks-1; i++)
               if (F->sorttag[i]==sector)
                  {newsector=F->sorttag[i+1]; printsector(stdout,F,sector,F->sectorsize);break;}
           }

           if (newsector<=F->numblocks && newsector!=sector) sector=newsector;
           else puts("This sector is the end of this chain.");
           break;

       case SORT_PREV:
           if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
           if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
           { for (i=1; i<=F->numblocks-1; i++)
               if (F->sorttag[i]==sector)
                  {newsector=F->sorttag[i-1]; printsector(stdout,F,sector,F->sectorsize);break;}
           }

           if (newsector<=F->numblocks && newsector!=sector) sector=newsector;
           else puts("This sector is the start of this chain.");
           break;

       case DIR_CMD:
            if (!havetags) {puts("I can't do that, this image doesn't have tags."); break;}
            if (!tagsaresorted) {sorttags(F);    tagsaresorted=1;}
            //                 01234567890123456789012345678912
            printf("\nFileID   FileName                           start sector\n");
            printf("----------------------------------------------------------\n%s\n",directory);
            break;

       case  VERSION_CMD: version_banner(); break;
       case  HELP_CMD:
           version_banner();
           puts("NOTE: This program relies on tag data to perform commands marked by a + sign.");
           puts("It also requires that the disk images be imaged by Apple Disk Copy 4.2.  It");
           puts("can't use DART images.  If you know DART's format details, please contact me.");
           puts("Versions of ADC newer than 4.2 do not extract tags!  Although they claim to be");
           puts("able to convert DART to DC4.2, they strip off the tags, rendering them useless.");
           puts("");
           puts("    It only understands Lisa disk images with tags made by Disk Copy 4.2");
           puts("");
           puts("help            - displays this help screen.");
           puts("version         - displays version and copyright.");
           puts("{sector#}       - jump and display a sector #. (press ENTER for next one.)");
           puts("+|-{#}          - skip forward/backward by # of sectors.");
           puts("display         - display a sector #");
           puts("cluster         - display the 1st sector in a cluster.");
           puts("setclustersize  - set the cluster size.");
           puts("dump            - dump all sectors and tags in hex display");
           puts("n/p             + next/previous display in sorted chain.");
           puts("tagdump         + dump tags");
           puts("sorttagdump     + sort tags by file ID and sector #, then dump them");
           puts("sortdump        + same as above, but also output actual sectors");
           puts("bitmap          + show block allocation bitmap");
           puts("extract         + extracts all files on disk based on tag data.");
           puts("                  files are written to the current directory and named based");
           puts("                  on the file id and Disk Copy image name.");
           puts("dir             + list tag file ID's and extracted file names from catalog.");
           puts("quit            - exit program.");
           puts("");
           break;


       case  QUIT_CMD: /* quit       */; exit (0);break;
   }
 }
}

int main (int argc, char *argv[])
{
int i;

    version_banner();
	if (argc<1)
	{
      puts("Usage: lisafsh file.image");
	  exit(0);
	}

    F.fhandle=fopen(argv[1],"rb");
	F.filename=argv[1];
    if (!F.fhandle) {perror("Could not open file because"); exit(1);}

	F.sectors=NULL;
	F.tags=NULL;

	i=floppy_disk_copy_image_open(&F);

    // clear the volume name, sorting the tags will set it.
    memset(volumename,0,31);
    memset(directory,0,65535);
    if (havetags) if (!tagsaresorted) {sorttags(&F);   tagsaresorted=1;}


    if (i) {fprintf(stderr,"Had trouble reading the disk image");}

	cli(&F);

    fclose(F.fhandle);
return 0;
}

  ---------------------------------------------------------------------------
    Lisa File System Shell Tool  v0.1      http://lisaem.sunder.net/lisafsh  
  ---------------------------------------------------------------------------
        Copyright (C) MMIV, Ray A. Arachelian,   All Rights Reserved.
              Released under the GNU Public License, Version 2.0

        See: http://www.gnu.org/licenses/gpl.html for License Details

    There is absolutely no warranty for this program. Use at your own risk.  
  ---------------------------------------------------------------------------

This program is meant to be used as a tool to help with the extraction and
transfer of information from images of Apple Lisa 3.5" floppy disks.  It is
released under the GNU Public License, see the above link for details on
the GNU project and license details.


The following people have contributed to this project and are recognized
here:  David T. Craig who has provided a wealth of information, Chris McFall
who provided details about the MDDF, and Natalia Portillo  who wishes to
write a universal file system API.

This is a rough first draft of this program intended for my own use.  I've
released this in the hopes that it will prove useful to others, despite
it's current limitations.

It currently lacks quite a number of features that would make it more useful 
to the general public, including but not limited to:

1. Command Line interface is too rough, not shell-like enough. 
2. No open/close command, you can only work with one disk image which must
   be entered in at the command line at launch time.

   i.e.  lisafsh Office_Sys_1.dc42
 
3. It doesn't allow you to edit/save the Disk Copy 4.2 image.  I need to figure
   out how to correctly calculate the checksums first
4. Some information from the disk is not properly extracted which can lead
   to issues (i.e. wrong data extracted, etc.) These include:
  
   Extents - 	These are the left over chunks of a file which do not fully
		fit into a single sector.  The File System designers
		wanted to save space, and so these are allocated in special
		sectors elsewhere on the disk.  (Unlike for example the
		FAT file system which can waste an entire cluster for a
		few bytes.)  This means that upto the last 511 bytes of a
		file may not be extracted by this program.
 
   B-Tree/	This program relies on the extra tag information which wasn't
   Hashes/	meant for much other than data repair/scavenging (i.e. fsck)
   Table	There are three versions of the Apple Lisa File System.
		The first is a flat file system with a table, the second uses
		Hashes, and the newest uses a B-Tree structure.  I've not yet
		reverse engineered these, so the extraction is not tag 
		independent.  See below for an explanation.

   MDDF		Only the FS version and volume name fields are known to me.

   DART		The DART (Disk Archiver Tool) program has its own format which
		compresses sectors.  Unlike the DiskCopy 4.2, I was unable to
		find out any information about it's format at all.  If you
		know it's format and are willing to share it, please contact 
		me.



Information about old Macintosh and Apple Lisa Disks:

 Originally, the 1st Lisa shipped with a proprietary 5.25" double sided floppy
disk called Twiggy.  These were later replaced by Sony 3.5" single sided,
double density floppy drives with the introduction of the Lisa 2 upgrades.

The 400K floppies were formatted using a method called GCR (Group Coded Record)
which meant that some tracks contained more sectors than others because they
had more surface area under them. (Also, the disk motor spun at different speeds
for different groups of tracks.)  As with most storage devices, these used
512 byte sectors (the original Twiggy disks used 256 byte sectors I believe.)

The Lisa engineers also added 12 bytes of meta data to each sector called tags,
and these include information such as the Volume ID, the File ID the sector
belongs to, as well as next/previous pointers.  It also turns out that some
file ID's are used reserved.  For example AAAA is the boot sector, BBBB is
the OS loader, 0000 is a free block, 0001 is the MDDF (aka superblock), etc.

The original Macintosh also used this 400K drive and a flat file system called
MFS.  When later versions of the Macintosh were introduced, they used a new
SuperDrive (not to be confused with the current DVD burners!) which could
also access MFM (PC) formatted floppies and high density 1.44MB floppies.

There are two applications for the classic 68K Macintosh computers that can
work with Lisa formatted disks.  These are DART and Apple Disk Copy.  This
program only understands Disk Copy 4.2 disk images.

With later versions of Mac OS, the older 400K floppies (and the original MFS)
file system were no longer supported, (eventually, floppies were also no longer
supported) and over time tag information on the older disks were ignored by
tools such as Disk Copy.

While new versions of Disk Copy have added a conversion feature to help
migrate DART images to Disk Copy 4.2 format, they strip off all tag information.

Unfortunately at least in this initial version of the Lisa File System Shell,
I rely on the information stored in the tags to get at the files. 

Because of this, you will not be able convert any DART images this way.  You
will need access to an old Macintosh which can read/write 400k/800k floppies.
You will then need to use DART to restore the disk image to the floppy, and
then use Disk Copy 4.2 to create a new image.  Good luck finding 3.5" double
sided disks.  Some claim that it's possible to tape the sensor hole that
indicates a HD floppy.  I've not tried it.

Also note that the Lisa Operating system used features not available on current
operating systems.  You can have split files which means that a file is broken
up in multiple pieces across many disks.  You can also have two files with the
same exact name, or slashes as part of the file name.  A lot of this 
functionality was implemented by occluding the real file names from the user
which is why you won't see the OS/driver file names from the Desktop.

At the low level, your documents will show up as something like {D1234T1}
and not "Business report 5/12/1971"  This is because some files have metadata
attached as the first 0xf0 bytes.   When you extract such files, you'll find
extra file named .meta.txt .meta.bit which separate the metadata out.



The following is the help screen from the program:

NOTE: This program relies on tag data to perform commands marked by a + sign.
It also requires that the disk images be imaged by Apple Disk Copy 4.2.  It
can't use DART images.  If you know DART's format details, please contact me.
Versions of ADC newer than 4.2 do not extract tags!  Although they claim to be
able to convert DART to DC4.2, they strip off the tags, rendering them useless.

    It only understands Lisa disk images with tags made by Disk Copy 4.2

help            - displays this help screen.
version         - displays version and copyright.
{sector#}       - jump and display a sector #. (press ENTER for next one.)
+|-{#}          - skip forward/backward by # of sectors.
display         - display a sector #
cluster         - display the 1st sector in a cluster.
setclustersize  - set the cluster size.
dump            - dump all sectors and tags in hex display
n/p             + next/previous display in sorted chain.
tagdump         + dump tags
sorttagdump     + sort tags by file ID and sector #, then dump them
sortdump        + same as above, but also output actual sectors
bitmap          + show block allocation bitmap
extract         + extracts all files on disk based on tag data.
                  files are written to the current directory and named based
                  on the file id and Disk Copy image name.
dir             + list tag file ID's and extracted file names from catalog.
quit            - exit program.

When you launch the program from the command line, with a disk image as it's first
and only parameter, it will open it and display the Disk Copy 4.2 image information
about the disk image.  It looks like this:

Header comment :"-not a Macintosh disk-"
Data Size      :409600 (0x00064000)
Tag total      :-128 (0xffffff80)
Data checksum  :0 (0x00000000)
Tag checksum   :0 (0x00000000)
Disk format    :0  400K GCR
Format byte    :0x02   unknown
Private        :0x0100 (should be 0x100)
Data starts at :0x0054 (84)
Tags start at  :0x64054 (409684)
No of sectors  :0x0320 (800)
Sector size    :0x0200 (512)
tag size       :0x51eb84 (5368708)

Sector Navigation:

To move from sector to sector, you can simply type in the sector number and hit enter.
To move to the next sector hit ENTER.  To jump 3 sectors from the current one, you can
type in +3.  To go back 5 sectors, you can type in -5.  The display will look like
this:

-----------------------------------------------------------------------------
Sec 1:(0x0001)   Used Block Part of file OSLoader-bbbb:"OSLoader-bbbb"
-----------------------------------------------------------------------------

The top banner tells you in both decimal and hexidecimal the sector number
that you are viewing, whether the block is a Free or Used block, and which
file it belongs to.  Note that some files are special and aren't in the
directory.  For example the boot sector and the OS loader.  These aren't
really files, however, I treat them as such in order to be able to extract
them in a consistant manner.  The file name is shown twice here, this is
because it's a special file.  The bbbb that you see next to the name is
the file ID from the tag information.

Next, there is the tag display that shows you a ruler indicating by position
the tag location, followed by the actual tags on the next line, and below it
a legend:

-----------------------------------------------------------------------------
            +0 +1 +2 +3 +4 +5 . +6 +7 +8 +9 +a +b
tags:       00 00 00 24 bb bb . 00 01 87 ff 07 ff             
           |volid| ??  |fileid|absnext|next|previous
-----------------------------------------------------------------------------

Note that tag bytes 4,5 are the file ID and contain the "bbbb" mentioned
previously.

Next, you'll see the ruler for the data in the sector, followed by the
data.  On the left, you can see the byte offset (in hexidecimal) for the
line displayed on each row.  This is followed by the data represented in
hexidecimal, a separator, and a possible ASCII representation of that
data.

-----------------------------------------------------------------------------
      +0 +1 +2 +3 +4 +5 +6 +7 . +8 +9 +a +b +c +d +e +f                    
-----------------------------------------------------------------------------
0000: c0 01 42 80 24 3c 00 30 . 00 00 4e ba ff 14 4e b9   |  @!B $< 0  N:4N9
0010: 00 fe 00 94 64 00 00 0a . 30 3c ff ff 60 00 00 4c   |   ~ 4d  *0<`  L
...

Another example:  a small snippet of data from sector 3 that also shows text:

0130: 00 84 4f 53 20 42 4f 4f . 54 20 46 41 49 4c 45 44   |   $OS BOOT FAILED
0140: 20 20 20 20 20 20 54 52 . 59 20 41 20 4e 45 57 45   |        TRY A NEWE
0150: 52 20 4d 41 43 48 49 4e . 45 20 41 4e 44 20 42 4f   |  R MACHINE AND BO
0160: 4f 54 20 50 52 4f 4d 00 . 20 5f 22 5f 4e 91 4e d0   |  OT PROM  _"_N1NP
0170: 2f 02 41 fa 20 6c 4e 90 . 4e 75 20 5f 2e 8d 4e d0   |  /"Az lN0Nu _.-NP


Allocated/Free sectors:

The file system contains a special file which is a bitmap of all the sectors 
on the disk.  This bitmap uses one bit for each sector.  As you might imagine
there are a lot more bytes in this bitmap than can represent sectors, so the
bottom of this sector is mostly empty.

To see the block allocation bitmap, type in bitmap:

lisafsh> bitmap

                  Block allocation bitmap
----------+----------------------------------------+
Sector    |..........1.........2........3..........|
hex dec  +|0123456789012345678901234567890123456789|
----------+----------------------------------------|
0000(0000)|########################################|
0028(0040)|########################################|
0050(0080)|############             ###############|
0078(0120)|########################################|


The sectors marked with #'s are allocated, those with blank spaces are free.
At the top there is a horizontal ruler, on the left column for each row,
there is the offset (in both hex and decimal.)  Adding the sector number
from the left column to the top offset matching the row in question lets
you find the sector you're interested in.  For example, the first free
sector for this disk is at sector 92.  (80+12).

Seeing the file names:

To see a list of files, their file ID's, and their first sector number,
type in DIR.  The FileID is in the left column, followed by the Lisa
file name, then the starting sector, represented in hex and decimal:

FileID   FileName                           start sector
----------------------------------------------------------
0018     apin/syslib.obj                     0294(660)
0009     SYSTEM.BT_PROFILE                   009d(157)
000b     SYSTEM.CDD                          00ca(202)
000c     SYSTEM.CD_2 PORT CARD               00cd(205)
0008     officephrase                        007b(123)
...

To follow a file, you can type in it's sector number, hit
ENTER, then repeatedly use the n command to follow to the next 
sector of the file you wish to view.  

[There's a bug where you'll need to use the "n" command twice
initially.  Also if you follow the file past its end, it will
display sectors  to the next file.]



Extraction of information and files:

If you would like to use this tool in as a batch tool from a shell script, you can use
Unix's redirection features to pipe a command for it to execute and optionally redirect
the output to a file.

For example to extract all the files inside of a disk image:

          echo extract | lisafsh Office_Sys_1.dc42

To get a hex dump of all the sectors in the disk image:

	  echo dump } lisafsh Office_Sys_1.dc42 >Office_Sys_1.dump.txt



To exit the program, type in quit.


If you wish to contact me, my email address is:

  my first name AT my last name dot com.  :)
